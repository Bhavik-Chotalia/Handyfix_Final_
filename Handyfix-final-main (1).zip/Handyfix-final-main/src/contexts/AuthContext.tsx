import React, { createContext, useContext, useEffect, useState } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role?: 'user';
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
  isGuest: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  signup: (email: string, password: string, name: string, phone?: string) => Promise<void>;
  logout: () => void;
  continueAsGuest: () => void;
  isProvider: boolean;
  userRole: 'user' | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGuest, setIsGuest] = useState(false);

  useEffect(() => {
    // Check for existing session on mount
    const checkSession = () => {
      const storedToken = localStorage.getItem('handyfix-token');
      const storedUser = localStorage.getItem('handyfix-user');
      const guestMode = localStorage.getItem('handyfix-guest');

      if (guestMode === 'true') {
        setIsGuest(true);
      } else if (storedToken && storedUser) {
        try {
          setToken(storedToken);
          const userData = JSON.parse(storedUser);
          setUser(userData);
        } catch {
          localStorage.removeItem('handyfix-token');
          localStorage.removeItem('handyfix-user');
        }
      }
      setIsLoading(false);
    };

    checkSession();
  }, []);

  const login = async (email: string, password: string, rememberMe = false) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const responseText = await response.text();
        console.error('Login error response:', responseText);
        try {
          const errorData = JSON.parse(responseText);
          throw new Error(errorData.message || 'Login failed');
        } catch {
          throw new Error(`Login failed: ${response.status} ${response.statusText}. Please ensure the backend server is running.`);
        }
      }

      const responseText = await response.text();
      if (!responseText) {
        throw new Error('Empty response from server. Please ensure the backend server is running.');
      }

      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Failed to parse response:', responseText);
        throw new Error('Invalid response format from server. Please ensure the backend server is running correctly.');
      }

      const { token: authToken, user: userData } = data;

      setToken(authToken);
      setUser(userData);
      setIsGuest(false);

      localStorage.setItem('handyfix-token', authToken);
      localStorage.setItem('handyfix-user', JSON.stringify(userData));
      localStorage.removeItem('handyfix-guest');

      if (!rememberMe) {
        sessionStorage.setItem('handyfix-user', JSON.stringify(userData));
      }

      // Fetch full profile after login
      try {
        const profileResponse = await fetch('/api/profile/me', {
          headers: {
            'Authorization': `Bearer ${authToken}`,
          },
        });
        if (profileResponse.ok) {
          const profileData = await profileResponse.json();
          localStorage.setItem('handyfix-profile', JSON.stringify(profileData));
        }
      } catch (profileError) {
        console.warn('Could not fetch profile:', profileError);
      }

      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  const signup = async (email: string, password: string, name: string, phone?: string) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, name, phone: phone || '', role: 'user' }),
      });

      if (!response.ok) {
        const responseText = await response.text();
        console.error('Signup error response:', responseText);
        try {
          const errorData = JSON.parse(responseText);
          throw new Error(errorData.message || 'Signup failed');
        } catch {
          throw new Error(`Signup failed: ${response.status} ${response.statusText}. Please ensure the backend server is running.`);
        }
      }

      const responseText = await response.text();
      if (!responseText) {
        throw new Error('Empty response from server. Please ensure the backend server is running.');
      }

      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Failed to parse response:', responseText);
        throw new Error('Invalid response format from server. Please ensure the backend server is running correctly.');
      }

      const { token: authToken, user: userData } = data;

      setToken(authToken);
      setUser(userData);
      setIsGuest(false);

      localStorage.setItem('handyfix-token', authToken);
      localStorage.setItem('handyfix-user', JSON.stringify(userData));
      localStorage.removeItem('handyfix-guest');

      // Fetch full profile after signup
      try {
        const profileResponse = await fetch('/api/profile/me', {
          headers: {
            'Authorization': `Bearer ${authToken}`,
          },
        });
        if (profileResponse.ok) {
          const profileData = await profileResponse.json();
          localStorage.setItem('handyfix-profile', JSON.stringify(profileData));
        }
      } catch (profileError) {
        console.warn('Could not fetch profile:', profileError);
      }

      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      throw error;
    }
  };

  const continueAsGuest = () => {
    setUser(null);
    setToken(null);
    setIsGuest(true);
    localStorage.setItem('handyfix-guest', 'true');
    localStorage.removeItem('handyfix-token');
    localStorage.removeItem('handyfix-user');
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setIsGuest(false);
    localStorage.removeItem('handyfix-token');
    localStorage.removeItem('handyfix-user');
    localStorage.removeItem('handyfix-guest');
    sessionStorage.removeItem('handyfix-user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user && !!token,
      isLoading,
      token,
      isGuest,
      login,
      signup,
      logout,
      continueAsGuest,
      isProvider: false,
      userRole: user?.role || null,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
