import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { LogOut, User, Briefcase } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout, isAuthenticated, token } = useAuth();
  const { toast } = useToast();
  const [isProvider, setIsProvider] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }

    // Check if user has provider profile
    const checkProviderStatus = async () => {
      try {
        if (!token) return;
        
        const response = await fetch('/api/providers/me', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const providerData = await response.json();
          setIsProvider(true);
          localStorage.setItem('handyfix-provider', JSON.stringify({ 
            isProvider: true,
            providerId: providerData._id,
            isVerified: providerData.isVerified,
          }));
        }
      } catch (error) {
        // Provider profile doesn't exist yet
        setIsProvider(false);
      }
    };

    checkProviderStatus();
  }, [isAuthenticated, navigate, token]);

  const handleLogout = () => {
    logout();
    navigate('/');
    toast({
      title: 'Logged out',
      description: 'You have been logged out successfully',
    });
  };

  const goToCustomerMode = () => {
    navigate('/customer');
  };

  const goToProviderMode = () => {
    if (!isProvider) {
      navigate('/provider-setup');
    } else {
      navigate('/provider');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">HandyFix Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-card border border-border/50">
              <User className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-foreground">{user?.name}</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            What would you like to do?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Choose your mode to get started with HandyFix
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Customer Mode Card */}
          <div className="group relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-0 group-hover:opacity-100" />
            <div className="relative bg-card border border-border/50 rounded-2xl p-8 hover:border-primary/50 transition-all duration-300">
              <div className="mb-6">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <Briefcase className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">
                  Find a Service
                </h3>
                <p className="text-muted-foreground">
                  Post a service request and connect with verified service providers in your area
                </p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-sm text-foreground">Browse available services</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-sm text-foreground">Post service requests</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-sm text-foreground">Track job status</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                  <span className="text-sm text-foreground">Rate and review providers</span>
                </div>
              </div>

              <Button
                onClick={goToCustomerMode}
                variant="hero"
                size="lg"
                className="w-full"
              >
                Find a Service
              </Button>
            </div>
          </div>

          {/* Provider Mode Card */}
          <div className="group relative">
            <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-accent/10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300 opacity-0 group-hover:opacity-100" />
            <div className="relative bg-card border border-border/50 rounded-2xl p-8 hover:border-accent/50 transition-all duration-300">
              <div className="mb-6">
                <div className="w-16 h-16 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                  <Briefcase className="w-8 h-8 text-accent" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">
                  Earn as Service Provider
                </h3>
                <p className="text-muted-foreground">
                  {isProvider ? 'Accept jobs and grow your business' : 'Register as a service provider and start earning'}
                </p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="text-sm text-foreground">Accept service requests</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="text-sm text-foreground">Manage your jobs</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="text-sm text-foreground">Track earnings</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="text-sm text-foreground">Build your reputation</span>
                </div>
              </div>

              <Button
                onClick={goToProviderMode}
                variant={isProvider ? 'hero' : 'outline'}
                size="lg"
                className="w-full"
              >
                {isProvider ? 'Go to Provider Panel' : 'Become a Provider'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
