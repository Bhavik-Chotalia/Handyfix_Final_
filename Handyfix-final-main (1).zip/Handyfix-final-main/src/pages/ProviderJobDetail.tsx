import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, MapPin, Calendar, DollarSign, User, Phone, Mail } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Job {
  _id: string;
  serviceType: string;
  description: string;
  location: string;
  status: string;
  budget?: number;
  actualPrice?: number;
  createdAt: string;
  customerId: {
    name: string;
    email: string;
    phone: string;
  };
}

const ProviderJobDetail: React.FC = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, token } = useAuth();
  const { toast } = useToast();

  const [job, setJob] = useState<Job | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [newStatus, setNewStatus] = useState('');
  const [actualPrice, setActualPrice] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    if (jobId) {
      fetchJobDetails();
    }
  }, [isAuthenticated, navigate, jobId, token]);

  const fetchJobDetails = async () => {
    try {
      if (!token) return;

      const response = await fetch(`/api/bookings/${jobId}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setJob(data);
        setNewStatus(data.status);
        setActualPrice(data.actualPrice?.toString() || '');
      }
    } catch (error) {
      console.error('Error fetching job details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load job details',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!token || !jobId) return;

    if (newStatus === 'completed' && !actualPrice) {
      toast({
        title: 'Error',
        description: 'Please set the actual price to complete the job',
        variant: 'destructive',
      });
      return;
    }

    setIsUpdating(true);

    try {
      const response = await fetch(`/api/bookings/${jobId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: newStatus,
          actualPrice: actualPrice ? parseFloat(actualPrice) : null,
        }),
      });

      if (response.ok) {
        const updatedJob = await response.json();
        setJob(updatedJob.job);
        toast({
          title: 'Success',
          description: `Job status updated to ${newStatus.replace('_', ' ')}`,
        });
      }
    } catch (error) {
      console.error('Error updating job status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update job status',
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-yellow-100 text-yellow-800';
      case 'in_progress':
        return 'bg-purple-100 text-purple-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const statusOptions = ['accepted', 'in_progress', 'completed'];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading job details...</p>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Job not found</p>
          <Button onClick={() => navigate('/provider')}>Back to Provider Panel</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/provider')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground capitalize">{job.serviceType}</h1>
            <p className="text-sm text-muted-foreground">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
                {job.status.replace('_', ' ').toUpperCase()}
              </span>
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Info */}
          <div className="md:col-span-2 space-y-6">
            {/* Job Details */}
            <Card className="p-6 border border-border/50">
              <h2 className="text-lg font-bold text-foreground mb-4">Job Details</h2>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Description</p>
                  <p className="text-foreground">{job.description}</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 pt-4 border-t border-border/30">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Location</p>
                      <p className="text-sm font-medium text-foreground">{job.location}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Requested</p>
                      <p className="text-sm font-medium text-foreground">
                        {new Date(job.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {job.budget && (
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Customer Budget</p>
                        <p className="text-sm font-medium text-foreground">${job.budget}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>

            {/* Customer Info */}
            <Card className="p-6 border border-border/50">
              <h2 className="text-lg font-bold text-foreground mb-4">Customer Information</h2>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Name</p>
                    <p className="text-sm font-medium text-foreground">{job.customerId.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm font-medium text-foreground">{job.customerId.email}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm font-medium text-foreground">{job.customerId.phone}</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Update Status Form */}
            {job.status !== 'completed' && (
              <Card className="p-6 border border-border/50">
                <h2 className="text-lg font-bold text-foreground mb-4">Update Job Status</h2>
                <form onSubmit={handleUpdateStatus} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Job Status
                    </label>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value)}
                      className="input-modern w-full"
                    >
                      {statusOptions.map((status) => (
                        <option key={status} value={status}>
                          {status.replace('_', ' ').toUpperCase()}
                        </option>
                      ))}
                    </select>
                  </div>

                  {newStatus === 'completed' && (
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Actual Price Charged *
                      </label>
                      <div className="relative">
                        <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <input
                          type="number"
                          value={actualPrice}
                          onChange={(e) => setActualPrice(e.target.value)}
                          placeholder="0.00"
                          step="0.01"
                          className="input-modern pl-10 w-full"
                          required
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Set the amount you charged for this job
                      </p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    variant="hero"
                    className="w-full"
                    disabled={isUpdating}
                  >
                    {isUpdating ? 'Updating...' : 'Update Status'}
                  </Button>
                </form>
              </Card>
            )}

            {job.status === 'completed' && (
              <Card className="p-6 border border-green-200 bg-green-50">
                <p className="text-green-800 font-medium">
                  This job has been completed. Customer can now review your service.
                </p>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <Card className="p-6 border border-border/50 sticky top-6">
              <h3 className="text-lg font-bold text-foreground mb-4">Summary</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-muted-foreground">Current Status</p>
                  <span className={`inline-block mt-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
                    {job.status.replace('_', ' ').toUpperCase()}
                  </span>
                </div>

                {job.actualPrice && (
                  <div>
                    <p className="text-xs text-muted-foreground">Actual Price</p>
                    <p className="text-lg font-bold text-foreground mt-1">
                      ${job.actualPrice.toFixed(2)}
                    </p>
                  </div>
                )}

                <div className="pt-4 border-t border-border/30">
                  <p className="text-xs text-muted-foreground">Next Steps</p>
                  <ul className="mt-2 space-y-2 text-sm text-foreground">
                    {job.status === 'accepted' && (
                      <>
                        <li>1. Start working on the job</li>
                        <li>2. Mark as "In Progress"</li>
                        <li>3. Set actual price</li>
                        <li>4. Mark as "Completed"</li>
                      </>
                    )}
                    {job.status === 'in_progress' && (
                      <>
                        <li>1. Finish the work</li>
                        <li>2. Set the final price</li>
                        <li>3. Mark as "Completed"</li>
                      </>
                    )}
                    {job.status === 'completed' && (
                      <li>Job completed. Awaiting customer review.</li>
                    )}
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderJobDetail;
