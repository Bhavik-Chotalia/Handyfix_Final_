import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Plus, MapPin, Calendar, DollarSign, Star } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Job {
  _id: string;
  serviceType: string;
  description: string;
  location: string;
  status: string;
  budget?: number;
  actualPrice?: number;
  createdAt: string;
  providerId?: { _id: string; userId: { name: string } };
}

const Customer: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, token } = useAuth();
  const { toast } = useToast();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    serviceType: '',
    description: '',
    location: '',
    preferredTime: '',
    budget: '',
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    fetchJobs();
  }, [isAuthenticated, navigate, token]);

  const fetchJobs = async () => {
    try {
      if (!token) return;
      
      const response = await fetch('/api/bookings/my-jobs', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setJobs(data);
      }
    } catch (error) {
      console.error('Error fetching jobs:', error);
      toast({
        title: 'Error',
        description: 'Failed to load your service requests',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!token) {
      toast({
        title: 'Error',
        description: 'You must be logged in',
        variant: 'destructive',
      });
      return;
    }

    try {
      const response = await fetch('/api/bookings/request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          serviceType: formData.serviceType,
          description: formData.description,
          location: formData.location,
          preferredTime: formData.preferredTime || null,
          budget: formData.budget ? parseFloat(formData.budget) : null,
        }),
      });

      if (response.ok) {
        const newJob = await response.json();
        setJobs([newJob.job, ...jobs]);
        setFormData({
          serviceType: '',
          description: '',
          location: '',
          preferredTime: '',
          budget: '',
        });
        setShowForm(false);
        toast({
          title: 'Success',
          description: 'Service request created successfully',
        });
      }
    } catch (error) {
      console.error('Error creating request:', error);
      toast({
        title: 'Error',
        description: 'Failed to create service request',
        variant: 'destructive',
      });
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'requested':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-yellow-100 text-yellow-800';
      case 'in_progress':
        return 'bg-purple-100 text-purple-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Find Services</h1>
              <p className="text-sm text-muted-foreground">Manage your service requests</p>
            </div>
          </div>
          <Button
            variant="hero"
            size="lg"
            onClick={() => setShowForm(!showForm)}
            className="gap-2"
          >
            <Plus className="w-5 h-5" />
            New Request
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Create Request Form */}
        {showForm && (
          <Card className="mb-8 p-6 border border-border/50">
            <h2 className="text-xl font-bold text-foreground mb-6">Create a Service Request</h2>
            <form onSubmit={handleCreateRequest} className="space-y-5">
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Service Type
                  </label>
                  <select
                    value={formData.serviceType}
                    onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                    className="input-modern w-full"
                    required
                  >
                    <option value="">Select service type</option>
                    <option value="plumbing">Plumbing</option>
                    <option value="electrical">Electrical</option>
                    <option value="carpentry">Carpentry</option>
                    <option value="painting">Painting</option>
                    <option value="cleaning">Cleaning</option>
                    <option value="hvac">HVAC</option>
                    <option value="appliance_repair">Appliance Repair</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="Your address"
                    className="input-modern w-full"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Preferred Time
                  </label>
                  <input
                    type="datetime-local"
                    value={formData.preferredTime}
                    onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                    className="input-modern w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Budget (Optional)
                  </label>
                  <input
                    type="number"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    placeholder="0"
                    className="input-modern w-full"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the service you need..."
                  className="input-modern w-full min-h-32"
                  required
                />
              </div>

              <div className="flex gap-3">
                <Button
                  type="submit"
                  variant="hero"
                  className="flex-1"
                >
                  Create Request
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* Jobs List */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading your requests...</p>
          </div>
        ) : jobs.length === 0 ? (
          <Card className="text-center py-12 border border-border/50">
            <p className="text-muted-foreground mb-4">No service requests yet</p>
            <Button
              variant="hero"
              onClick={() => setShowForm(true)}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Your First Request
            </Button>
          </Card>
        ) : (
          <div className="grid gap-6">
            {jobs.map((job) => (
              <Card
                key={job._id}
                className="p-6 border border-border/50 hover:border-primary/50 transition-all cursor-pointer"
                onClick={() => navigate(`/customer/job/${job._id}`)}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-foreground capitalize">
                        {job.serviceType}
                      </h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(job.status)}`}>
                        {job.status.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{job.description}</p>
                  </div>
                  {job.providerId && (
                    <div className="text-sm">
                      <p className="font-medium text-foreground">
                        {job.providerId.userId.name}
                      </p>
                    </div>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-border/30">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    {job.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    {new Date(job.createdAt).toLocaleDateString()}
                  </div>
                  {job.budget && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <DollarSign className="w-4 h-4" />
                      ${job.budget}
                    </div>
                  )}
                  {job.status === 'completed' && job.actualPrice && (
                    <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                      <DollarSign className="w-4 h-4" />
                      Paid: ${job.actualPrice}
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Customer;
