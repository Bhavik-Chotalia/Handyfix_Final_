import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ProviderSetup: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, token } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    skills: [] as string[],
    experience: '',
    location: '',
    bio: '',
  });

  const availableSkills = [
    'plumbing',
    'electrical',
    'carpentry',
    'painting',
    'cleaning',
    'hvac',
    'appliance_repair',
    'landscaping',
    'masonry',
    'roofing',
  ];

  if (!isAuthenticated) {
    navigate('/auth');
    return null;
  }

  const toggleSkill = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter((s) => s !== skill)
        : [...prev.skills, skill],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.skills.length === 0) {
      toast({
        title: 'Error',
        description: 'Please select at least one skill',
        variant: 'destructive',
      });
      return;
    }

    if (!formData.location) {
      toast({
        title: 'Error',
        description: 'Please enter your location',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      if (!token) {
        throw new Error('No authentication token');
      }

      const response = await fetch('/api/providers/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          skills: formData.skills,
          experience: formData.experience || '',
          location: formData.location,
          bio: formData.bio || '',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        
        // Store provider info
        localStorage.setItem('handyfix-provider', JSON.stringify({
          isProvider: true,
          providerId: data.provider.id,
          isVerified: data.provider.isVerified,
        }));

        toast({
          title: 'Success',
          description: 'Provider profile created. Awaiting admin verification.',
        });

        navigate('/provider');
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message);
      }
    } catch (error) {
      console.error('Error registering provider:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to register as provider',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Become a Service Provider</h1>
            <p className="text-sm text-muted-foreground">Complete your profile to start accepting jobs</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="p-8 border border-border/50">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Services Section */}
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-4">
                What services do you offer?
              </h2>
              <p className="text-sm text-muted-foreground mb-4">
                Select all the services you are skilled in
              </p>
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
                {availableSkills.map((skill) => (
                  <label
                    key={skill}
                    className="flex items-center gap-3 p-3 border border-border/50 rounded-lg cursor-pointer hover:bg-muted/50 transition-all"
                  >
                    <input
                      type="checkbox"
                      checked={formData.skills.includes(skill)}
                      onChange={() => toggleSkill(skill)}
                      className="w-4 h-4 rounded border-border"
                    />
                    <span className="text-sm font-medium text-foreground capitalize">
                      {skill.replace('_', ' ')}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Experience Section */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Experience Level
              </label>
              <select
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                className="input-modern w-full"
              >
                <option value="">Select experience level</option>
                <option value="beginner">Beginner (0-1 years)</option>
                <option value="intermediate">Intermediate (1-3 years)</option>
                <option value="advanced">Advanced (3-5 years)</option>
                <option value="expert">Expert (5+ years)</option>
              </select>
            </div>

            {/* Location Section */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Service Area Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="City or region where you provide services"
                className="input-modern w-full"
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                This helps customers find you based on their location
              </p>
            </div>

            {/* Bio Section */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Professional Bio (Optional)
              </label>
              <textarea
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                placeholder="Tell customers about yourself, your experience, and what makes you unique..."
                className="input-modern w-full min-h-32"
              />
              <p className="text-xs text-muted-foreground mt-1">
                This will appear on your profile
              </p>
            </div>

            {/* Verification Notice */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex gap-3">
                <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-blue-900 mb-1">Verification Required</h3>
                  <p className="text-sm text-blue-800">
                    Your profile will be reviewed by our admin team to ensure quality and reliability. 
                    You'll be notified once approved.
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-6">
              <Button
                type="submit"
                variant="hero"
                size="lg"
                className="flex-1"
                disabled={isLoading}
              >
                {isLoading ? 'Creating Profile...' : 'Create Provider Profile'}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="lg"
                className="flex-1"
                onClick={() => navigate('/dashboard')}
                disabled={isLoading}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default ProviderSetup;
