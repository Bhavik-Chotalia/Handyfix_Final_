import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Calendar,
  MapPin,
  Clock,
  Star,
  Download,
  MessageCircle,
  Trash2,
  RotateCcw,
} from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Booking {
  id: string;
  serviceName: string;
  serviceType: string;
  date: string;
  time: string;
  location: string;
  price: number;
  status: 'upcoming' | 'completed' | 'cancelled';
  providerName: string;
  image: string;
  rating?: number;
  reviewed?: boolean;
}

const MyBookings: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [activeFilter, setActiveFilter] = useState<'all' | 'upcoming' | 'completed' | 'cancelled'>('all');

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    }
  }, [isAuthenticated, navigate]);

  // Mock bookings data
  const mockBookings: Booking[] = [
    {
      id: '1',
      serviceName: 'Emergency Plumbing Repair',
      serviceType: 'plumbing',
      date: '2024-02-20',
      time: '10:00 AM',
      location: 'Mumbai, Maharashtra',
      price: 6750,
      status: 'upcoming',
      providerName: 'John Smith',
      image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=400&h=300&fit=crop',
    },
    {
      id: '2',
      serviceName: 'Interior Painting',
      serviceType: 'painting',
      date: '2024-02-15',
      time: '2:00 PM',
      location: 'Bangalore, Karnataka',
      price: 10800,
      status: 'completed',
      providerName: 'Sarah Johnson',
      image: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400&h=300&fit=crop',
      rating: 4.5,
      reviewed: true,
    },
    {
      id: '3',
      serviceName: 'AC Installation & Repair',
      serviceType: 'hvac',
      date: '2024-02-10',
      time: '11:00 AM',
      location: 'Delhi, Delhi',
      price: 8550,
      status: 'cancelled',
      providerName: 'Mike Chen',
      image: 'https://images.unsplash.com/photo-1631545806609-35d4ae440431?w=400&h=300&fit=crop',
    },
  ];

  const filteredBookings = mockBookings.filter((booking) => {
    if (activeFilter === 'all') return true;
    return booking.status === activeFilter;
  });

  const handleCancelBooking = (bookingId: string) => {
    toast({
      title: 'Booking Cancelled',
      description: 'Your booking has been cancelled successfully.',
    });
  };

  const handleReschedule = (bookingId: string) => {
    toast({
      title: 'Feature Coming Soon',
      description: 'Reschedule functionality will be available soon.',
    });
  };

  const handleDownloadInvoice = (bookingId: string) => {
    toast({
      title: 'Invoice Downloaded',
      description: 'Your invoice has been downloaded successfully.',
    });
  };

  const handleContactProvider = (bookingId: string) => {
    navigate(`/chat/${bookingId}`);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">
              My Bookings
            </h1>
            <p className="text-muted-foreground">
              View and manage all your service bookings
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-3 mb-6 overflow-x-auto">
            {(['all', 'upcoming', 'completed', 'cancelled'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                  activeFilter === filter
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-card border border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
                {' '}
                ({mockBookings.filter(b => b.status === filter).length})
              </button>
            ))}
          </div>

          {/* Bookings List */}
          <div className="space-y-4">
            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/50 transition-all"
                >
                  <div className="flex flex-col md:flex-row">
                    {/* Image */}
                    <div className="md:w-48 h-40 md:h-auto">
                      <img
                        src={booking.image}
                        alt={booking.serviceName}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-1 p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-foreground text-lg mb-1">
                            {booking.serviceName}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            by {booking.providerName}
                          </p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            booking.status === 'upcoming'
                              ? 'bg-blue-500/10 text-blue-700'
                              : booking.status === 'completed'
                              ? 'bg-green-500/10 text-green-700'
                              : 'bg-red-500/10 text-red-700'
                          }`}
                        >
                          {booking.status.charAt(0).toUpperCase() +
                            booking.status.slice(1)}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          {new Date(booking.date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          {booking.time}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          {booking.location}
                        </div>
                        <div className="font-semibold text-foreground">
                          ₹{booking.price.toLocaleString('en-IN')}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-wrap gap-3">
                        {booking.status === 'upcoming' && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleReschedule(booking.id)}
                              className="gap-2"
                            >
                              <RotateCcw className="w-4 h-4" />
                              Reschedule
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                handleCancelBooking(booking.id)
                              }
                              className="gap-2 text-destructive hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                              Cancel
                            </Button>
                          </>
                        )}

                        {booking.status === 'completed' && !booking.reviewed && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                          >
                            <Star className="w-4 h-4" />
                            Rate & Review
                          </Button>
                        )}

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadInvoice(booking.id)}
                          className="gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Invoice
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleContactProvider(booking.id)}
                          className="gap-2"
                        >
                          <MessageCircle className="w-4 h-4" />
                          Contact
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-16">
                <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
                  <Calendar className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold text-foreground text-lg mb-2">
                  No {activeFilter !== 'all' ? activeFilter : ''} bookings
                </h3>
                <p className="text-muted-foreground mb-6">
                  {activeFilter === 'all'
                    ? 'Browse services and book one today!'
                    : 'No bookings in this category.'}
                </p>
                <Button onClick={() => navigate('/services')}>
                  Browse Services
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MyBookings;
