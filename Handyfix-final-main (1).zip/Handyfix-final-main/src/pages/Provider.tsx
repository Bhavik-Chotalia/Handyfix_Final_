import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  ArrowLeft,
  AlertCircle,
  MapPin,
  DollarSign,
  Star,
  CheckCircle,
  Clock,
  Zap,
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Job {
  _id: string;
  serviceType: string;
  description: string;
  location: string;
  status: string;
  budget?: number;
  actualPrice?: number;
  customerId: { name: string; phone: string };
  createdAt: string;
}

interface Provider {
  _id: string;
  isVerified: boolean;
  isOnline: boolean;
  skills: string[];
  experience: string;
  location: string;
  rating: number;
  totalRatings: number;
  totalEarnings: number;
}

const Provider: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, token } = useAuth();
  const { toast } = useToast();

  const [provider, setProvider] = useState<Provider | null>(null);
  const [incomingRequests, setIncomingRequests] = useState<Job[]>([]);
  const [activeJobs, setActiveJobs] = useState<Job[]>([]);
  const [earnings, setEarnings] = useState({
    totalEarnings: 0,
    jobsCompleted: 0,
    rating: 0,
    totalRatings: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'requests' | 'active'>('overview');

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    fetchProviderData();
  }, [isAuthenticated, navigate, token]);

  const fetchProviderData = async () => {
    try {
      if (!token) return;

      // Fetch provider profile
      const providerRes = await fetch('/api/providers/me', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (!providerRes.ok) {
        navigate('/provider-setup');
        return;
      }

      const providerData = await providerRes.json();
      setProvider(providerData);

      // Fetch incoming requests
      const requestsRes = await fetch('/api/bookings/requests/incoming', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (requestsRes.ok) {
        const requestsData = await requestsRes.json();
        setIncomingRequests(requestsData);
      }

      // Fetch active jobs
      const jobsRes = await fetch('/api/bookings/provider/jobs', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (jobsRes.ok) {
        const jobsData = await jobsRes.json();
        setActiveJobs(jobsData.filter((j: Job) => j.status !== 'completed' && j.status !== 'cancelled'));
      }

      // Fetch earnings
      const earningsRes = await fetch('/api/bookings/provider/earnings', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (earningsRes.ok) {
        const earningsData = await earningsRes.json();
        setEarnings(earningsData);
      }
    } catch (error) {
      console.error('Error fetching provider data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load provider data',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleOnline = async () => {
    if (!provider || !token) return;

    try {
      const response = await fetch('/api/providers/status', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ isOnline: !provider.isOnline }),
      });

      if (response.ok) {
        setProvider({ ...provider, isOnline: !provider.isOnline });
        toast({
          title: provider.isOnline ? 'Offline' : 'Online',
          description: provider.isOnline
            ? 'You are now offline. Customers cannot see your profile.'
            : 'You are now online. Customers can see your profile and send requests.',
        });
      }
    } catch (error) {
      console.error('Error toggling online status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update status',
        variant: 'destructive',
      });
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    if (!provider || !provider.isVerified) {
      toast({
        title: 'Cannot Accept',
        description: 'You must be verified to accept jobs',
        variant: 'destructive',
      });
      return;
    }

    if (!token) return;

    try {
      const response = await fetch(`/api/bookings/${jobId}/accept`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        setIncomingRequests(incomingRequests.filter((r) => r._id !== jobId));
        fetchProviderData();
        toast({
          title: 'Success',
          description: 'Job accepted successfully',
        });
      }
    } catch (error) {
      console.error('Error accepting job:', error);
      toast({
        title: 'Error',
        description: 'Failed to accept job',
        variant: 'destructive',
      });
    }
  };

  const handleRejectJob = async (jobId: string) => {
    if (!token) return;

    try {
      const response = await fetch(`/api/bookings/${jobId}/reject`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        setIncomingRequests(incomingRequests.filter((r) => r._id !== jobId));
        toast({
          title: 'Job Rejected',
          description: 'You have rejected this job request',
        });
      }
    } catch (error) {
      console.error('Error rejecting job:', error);
      toast({
        title: 'Error',
        description: 'Failed to reject job',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading your provider dashboard...</p>
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Provider profile not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Provider Dashboard</h1>
              <p className="text-sm text-muted-foreground">{user?.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {!provider.isVerified && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-yellow-100 border border-yellow-200">
                <AlertCircle className="w-4 h-4 text-yellow-700" />
                <span className="text-sm text-yellow-800">Pending Verification</span>
              </div>
            )}
            <Button
              variant={provider.isOnline ? 'hero' : 'outline'}
              onClick={handleToggleOnline}
              className="gap-2"
            >
              <Zap className={`w-4 h-4 ${provider.isOnline ? '' : 'opacity-50'}`} />
              {provider.isOnline ? 'Online' : 'Offline'}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 border border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Earnings</p>
                <p className="text-2xl font-bold text-foreground">
                  ${earnings.totalEarnings.toFixed(2)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-primary opacity-50" />
            </div>
          </Card>

          <Card className="p-6 border border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Jobs Completed</p>
                <p className="text-2xl font-bold text-foreground">{earnings.jobsCompleted}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 border border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Rating</p>
                <p className="text-2xl font-bold text-foreground">
                  {earnings.rating.toFixed(1)} / 5
                </p>
              </div>
              <Star className="w-8 h-8 text-yellow-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 border border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Reviews</p>
                <p className="text-2xl font-bold text-foreground">{earnings.totalRatings}</p>
              </div>
              <Star className="w-8 h-8 text-blue-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-border/40">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'requests'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            Incoming Requests ({incomingRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('active')}
            className={`px-4 py-3 font-medium border-b-2 transition-colors ${
              activeTab === 'active'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            Active Jobs ({activeJobs.length})
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <Card className="p-6 border border-border/50">
            <h2 className="text-xl font-bold text-foreground mb-6">Profile Information</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-semibold text-foreground mb-4">Services Offered</h3>
                <div className="flex flex-wrap gap-2">
                  {provider.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
                    >
                      {skill.replace('_', ' ')}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-4">Experience</h3>
                <p className="text-foreground capitalize">{provider.experience}</p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-4">Service Area</h3>
                <div className="flex items-center gap-2 text-foreground">
                  <MapPin className="w-4 h-4" />
                  {provider.location}
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-4">Status</h3>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      provider.isVerified ? 'bg-green-500' : 'bg-yellow-500'
                    }`}
                  />
                  <span className="text-foreground">
                    {provider.isVerified ? 'Verified' : 'Pending Verification'}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        )}

        {activeTab === 'requests' && (
          <div className="space-y-4">
            {incomingRequests.length === 0 ? (
              <Card className="p-8 text-center border border-border/50">
                <Clock className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
                <p className="text-muted-foreground">No incoming requests at the moment</p>
                <p className="text-sm text-muted-foreground mt-2">
                  {provider.isOnline
                    ? 'Go online to accept new requests'
                    : 'Turn online to receive requests'}
                </p>
              </Card>
            ) : (
              incomingRequests.map((request) => (
                <Card key={request._id} className="p-6 border border-border/50">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground capitalize">
                        {request.serviceType}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">{request.description}</p>
                      <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {request.location}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">{request.customerId.name}</p>
                      <p className="text-sm text-muted-foreground">{request.customerId.phone}</p>
                    </div>
                  </div>
                  <div className="flex gap-3 pt-4 border-t border-border/30">
                    <Button
                      onClick={() => handleAcceptJob(request._id)}
                      variant="hero"
                      className="flex-1"
                      disabled={!provider.isVerified}
                    >
                      Accept Job
                    </Button>
                    <Button
                      onClick={() => handleRejectJob(request._id)}
                      variant="outline"
                      className="flex-1"
                    >
                      Reject
                    </Button>
                  </div>
                </Card>
              ))
            )}
          </div>
        )}

        {activeTab === 'active' && (
          <div className="space-y-4">
            {activeJobs.length === 0 ? (
              <Card className="p-8 text-center border border-border/50">
                <CheckCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
                <p className="text-muted-foreground">No active jobs at the moment</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Accept incoming requests to start working on jobs
                </p>
              </Card>
            ) : (
              activeJobs.map((job) => (
                <Card
                  key={job._id}
                  className="p-6 border border-border/50 cursor-pointer hover:border-primary/50 transition-all"
                  onClick={() => navigate(`/provider/job/${job._id}`)}
                >
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground capitalize">
                        {job.serviceType}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">{job.description}</p>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 w-fit">
                      {job.status.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  <div className="grid sm:grid-cols-3 gap-4 pt-4 border-t border-border/30">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {job.location}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{job.customerId.name}</p>
                    </div>
                    {job.actualPrice && (
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                        <DollarSign className="w-4 h-4" />
                        ${job.actualPrice}
                      </div>
                    )}
                  </div>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Provider;
