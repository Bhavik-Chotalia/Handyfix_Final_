import React, { useState } from 'react';
import { Search, Star, Clock, ChevronDown, X, Filter } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';

const serviceCategories = [
  { id: 'all', name: 'All Services' },
  { id: 'plumbing', name: 'Plumbing' },
  { id: 'electrical', name: 'Electrical' },
  { id: 'carpentry', name: 'Carpentry' },
  { id: 'painting', name: 'Painting' },
  { id: 'cleaning', name: 'Cleaning' },
  { id: 'hvac', name: 'HVAC' },
  { id: 'appliance', name: 'Appliance Repair' },
  { id: 'landscaping', name: 'Landscaping' },
];

const priceRanges = [
  { id: 'all', label: 'All Prices' },
  { id: 'budget', label: 'Under ₹4,500' },
  { id: 'mid', label: '₹4,500 - ₹9,000' },
  { id: 'premium', label: '₹9,000+' },
];

const services = [
  {
    id: 1,
    name: 'Emergency Plumbing Repair',
    category: 'plumbing',
    description: '24/7 emergency plumbing services for leaks, clogs, and pipe repairs.',
    price: 6750,
    rating: 4.9,
    reviews: 234,
    duration: '1-2 hours',
    image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=400&h=300&fit=crop',
    popular: true,
  },
  {
    id: 2,
    name: 'Electrical Panel Upgrade',
    category: 'electrical',
    description: 'Upgrade your electrical panel for improved safety and capacity.',
    price: 13500,
    rating: 4.8,
    reviews: 189,
    duration: '4-6 hours',
    image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400&h=300&fit=crop',
    popular: false,
  },
  {
    id: 3,
    name: 'Custom Furniture Building',
    category: 'carpentry',
    description: 'Handcrafted custom furniture tailored to your specifications.',
    price: 18000,
    rating: 4.9,
    reviews: 156,
    duration: '1-2 weeks',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop',
    popular: true,
  },
  {
    id: 4,
    name: 'Interior Painting',
    category: 'painting',
    description: 'Professional interior painting with premium quality paints.',
    price: 10800,
    rating: 4.7,
    reviews: 203,
    duration: '1-3 days',
    image: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400&h=300&fit=crop',
    popular: false,
  },
  {
    id: 5,
    name: 'Deep Home Cleaning',
    category: 'cleaning',
    description: 'Comprehensive deep cleaning service for your entire home.',
    price: 7650,
    rating: 4.8,
    reviews: 312,
    duration: '3-5 hours',
    image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&h=300&fit=crop',
    popular: true,
  },
  {
    id: 6,
    name: 'AC Installation & Repair',
    category: 'hvac',
    description: 'Professional AC installation, maintenance, and repair services.',
    price: 8550,
    rating: 4.6,
    reviews: 178,
    duration: '2-4 hours',
    image: 'https://images.unsplash.com/photo-1631545806609-35d4ae440431?w=400&h=300&fit=crop',
    popular: false,
  },
  {
    id: 7,
    name: 'Water Heater Installation',
    category: 'plumbing',
    description: 'Expert water heater installation and replacement services.',
    price: 16200,
    rating: 4.9,
    reviews: 145,
    duration: '3-4 hours',
    image: 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=400&h=300&fit=crop',
    popular: false,
  },
  {
    id: 8,
    name: 'Smart Home Wiring',
    category: 'electrical',
    description: 'Complete smart home wiring and automation setup.',
    price: 22500,
    rating: 4.8,
    reviews: 98,
    duration: '1-2 days',
    image: 'https://images.unsplash.com/photo-1558002038-1055907df827?w=400&h=300&fit=crop',
    popular: true,
  },
];

const Services: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedPrice, setSelectedPrice] = useState('all');
  const [sortBy, setSortBy] = useState('popular');
  const [showFilters, setShowFilters] = useState(false);

  const filteredServices = services.filter((service) => {
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          service.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    const matchesPrice = selectedPrice === 'all' ||
                         (selectedPrice === 'budget' && service.price < 4500) ||
                         (selectedPrice === 'mid' && service.price >= 4500 && service.price < 9000) ||
                         (selectedPrice === 'premium' && service.price >= 9000);
    return matchesSearch && matchesCategory && matchesPrice;
  });

  const sortedServices = [...filteredServices].sort((a, b) => {
    if (sortBy === 'popular') return b.reviews - a.reviews;
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    return 0;
  });

  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/5 via-transparent to-accent/5 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-10">
            <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Browse Our Services
            </h1>
            <p className="text-lg text-muted-foreground">
              Find the perfect service for your home needs from our wide range of professional offerings.
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-4xl mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search for services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-12 py-4 rounded-2xl bg-card border border-border shadow-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 hover:bg-muted rounded-lg transition-colors text-muted-foreground hover:text-foreground"
                title="Toggle filters"
              >
                <Filter className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Filters Bar */}
          {showFilters && (
            <div className="max-w-4xl mx-auto mb-6 animate-in fade-in slide-in-from-top-2">
              <div className="bg-card border border-border rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">Filters</h3>
                  <button
                    onClick={() => setShowFilters(false)}
                    className="p-1 hover:bg-muted rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-muted-foreground" />
                  </button>
                </div>
                <div className="space-y-4">
                  {/* Category Filter */}
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Categories</h4>
                    <div className="flex flex-wrap gap-2">
                      {serviceCategories.map((category) => (
                        <button
                          key={category.id}
                          onClick={() => setSelectedCategory(category.id)}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            selectedCategory === category.id
                              ? 'bg-primary text-primary-foreground shadow-md'
                              : 'bg-muted text-muted-foreground hover:bg-primary/10 hover:text-foreground'
                          }`}
                        >
                          {category.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Price Range Filter */}
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Price Range</h4>
                    <div className="flex flex-wrap gap-2">
                      {priceRanges.map((range) => (
                        <button
                          key={range.id}
                          onClick={() => setSelectedPrice(range.id)}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            selectedPrice === range.id
                              ? 'bg-primary text-primary-foreground shadow-md'
                              : 'bg-muted text-muted-foreground hover:bg-primary/10 hover:text-foreground'
                          }`}
                        >
                          {range.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sort and Clear Actions */}
                  <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between pt-3 border-t border-border/50">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Sort by:</span>
                      <div className="relative">
                        <select
                          value={sortBy}
                          onChange={(e) => setSortBy(e.target.value)}
                          className="appearance-none bg-muted border border-border rounded-lg px-3 py-2 pr-8 text-sm font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        >
                          <option value="popular">Most Popular</option>
                          <option value="rating">Highest Rated</option>
                          <option value="price-low">Price: Low to High</option>
                          <option value="price-high">Price: High to Low</option>
                        </select>
                        <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      </div>
                    </div>
                    {(selectedCategory !== 'all' || selectedPrice !== 'all') && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedCategory('all');
                          setSelectedPrice('all');
                        }}
                        className="text-muted-foreground hover:text-foreground"
                      >
                        Clear All Filters
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {/* Results Summary */}
          <div className="mb-6">
            <p className="text-muted-foreground">
              Showing <span className="font-medium text-foreground">{sortedServices.length}</span> services
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {sortedServices.map((service, index) => (
              <div 
                key={service.id} 
                className="service-card animate-fade-up"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="relative">
                  <img 
                    src={service.image} 
                    alt={service.name}
                    className="w-full h-48 object-cover rounded-xl"
                  />
                  {service.popular && (
                    <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                      Popular
                    </div>
                  )}
                </div>
                <div className="pt-4">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold text-foreground text-lg leading-tight">{service.name}</h3>
                    <span className="font-bold text-primary text-lg">₹{service.price.toLocaleString('en-IN')}</span>
                  </div>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{service.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-foreground">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        {service.rating}
                      </span>
                      <span className="text-muted-foreground">({service.reviews})</span>
                    </div>
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {service.duration}
                    </span>
                  </div>
                  <Button variant="default" className="w-full mt-4">
                    Book Now
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {sortedServices.length === 0 && (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-foreground text-xl mb-2">No services found</h3>
              <p className="text-muted-foreground">Try adjusting your filters or search query.</p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Services;
