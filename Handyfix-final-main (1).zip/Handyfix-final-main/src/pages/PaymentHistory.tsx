import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Download,
  CreditCard,
  Wallet,
  ArrowUpRight,
  Filter,
  Search,
} from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Transaction {
  id: string;
  date: string;
  serviceName: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  paymentMethod: string;
  transactionId: string;
  bookingId: string;
}

const PaymentHistory: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'completed' | 'pending' | 'failed'>('all');

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    }
  }, [isAuthenticated, navigate]);

  const mockTransactions: Transaction[] = [
    {
      id: '1',
      date: '2024-02-20',
      serviceName: 'Emergency Plumbing Repair',
      amount: 6750,
      status: 'completed',
      paymentMethod: 'Credit Card',
      transactionId: 'TXN123456',
      bookingId: 'BK001',
    },
    {
      id: '2',
      date: '2024-02-15',
      serviceName: 'Interior Painting',
      amount: 10800,
      status: 'completed',
      paymentMethod: 'UPI',
      transactionId: 'TXN123457',
      bookingId: 'BK002',
    },
    {
      id: '3',
      date: '2024-02-10',
      serviceName: 'AC Installation & Repair',
      amount: 8550,
      status: 'failed',
      paymentMethod: 'Debit Card',
      transactionId: 'TXN123458',
      bookingId: 'BK003',
    },
    {
      id: '4',
      date: '2024-02-05',
      serviceName: 'Deep Home Cleaning',
      amount: 7650,
      status: 'completed',
      paymentMethod: 'Wallet',
      transactionId: 'TXN123459',
      bookingId: 'BK004',
    },
    {
      id: '5',
      date: '2024-02-01',
      serviceName: 'Water Heater Installation',
      amount: 16200,
      status: 'pending',
      paymentMethod: 'Credit Card',
      transactionId: 'TXN123460',
      bookingId: 'BK005',
    },
  ];

  const filteredTransactions = mockTransactions.filter((transaction) => {
    const matchesSearch =
      transaction.serviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.transactionId.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      selectedStatus === 'all' || transaction.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  const totalAmount = filteredTransactions
    .filter((t) => t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const handleDownloadReceipt = (transactionId: string) => {
    toast({
      title: 'Receipt Downloaded',
      description: `Receipt for transaction ${transactionId} has been downloaded.`,
    });
  };

  const handleRetryPayment = (transactionId: string) => {
    toast({
      title: 'Feature Coming Soon',
      description: 'Retry payment functionality will be available soon.',
    });
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/10 text-green-700';
      case 'pending':
        return 'bg-yellow-500/10 text-yellow-700';
      case 'failed':
        return 'bg-red-500/10 text-red-700';
      default:
        return 'bg-gray-500/10 text-gray-700';
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4 max-w-5xl">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">
              Payment History
            </h1>
            <p className="text-muted-foreground">
              View all your transactions and download receipts
            </p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-card border border-border rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Total Spent</p>
                  <p className="font-display text-3xl font-bold text-foreground">
                    ₹{totalAmount.toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-primary" />
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Completed Payments</p>
                  <p className="font-display text-3xl font-bold text-foreground">
                    {mockTransactions.filter((t) => t.status === 'completed').length}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
                  <ArrowUpRight className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm mb-1">Pending Payments</p>
                  <p className="font-display text-3xl font-bold text-foreground">
                    {mockTransactions.filter((t) => t.status === 'pending').length}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-yellow-500/10 flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-card border border-border rounded-2xl p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by service name or transaction ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={selectedStatus === 'all' ? 'default' : 'outline'}
                  onClick={() => setSelectedStatus('all')}
                  className="gap-2"
                >
                  <Filter className="w-4 h-4" />
                  All
                </Button>
                <Button
                  variant={selectedStatus === 'completed' ? 'default' : 'outline'}
                  onClick={() => setSelectedStatus('completed')}
                >
                  Completed
                </Button>
                <Button
                  variant={selectedStatus === 'pending' ? 'default' : 'outline'}
                  onClick={() => setSelectedStatus('pending')}
                >
                  Pending
                </Button>
                <Button
                  variant={selectedStatus === 'failed' ? 'default' : 'outline'}
                  onClick={() => setSelectedStatus('failed')}
                >
                  Failed
                </Button>
              </div>
            </div>
          </div>

          {/* Transactions Table */}
          {filteredTransactions.length > 0 ? (
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted/50 border-b border-border">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Date
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Service
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Amount
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Method
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Status
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">
                        Transaction ID
                      </th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTransactions.map((transaction) => (
                      <tr
                        key={transaction.id}
                        className="border-b border-border hover:bg-muted/30 transition-colors"
                      >
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {new Date(transaction.date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-sm text-foreground font-medium">
                          {transaction.serviceName}
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold text-foreground">
                          ₹{transaction.amount.toLocaleString('en-IN')}
                        </td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {transaction.paymentMethod}
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(
                              transaction.status
                            )}`}
                          >
                            {transaction.status.charAt(0).toUpperCase() +
                              transaction.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {transaction.transactionId}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                handleDownloadReceipt(transaction.transactionId)
                              }
                              className="gap-2"
                            >
                              <Download className="w-4 h-4" />
                              Receipt
                            </Button>
                            {transaction.status === 'failed' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  handleRetryPayment(transaction.transactionId)
                                }
                              >
                                Retry
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 bg-card border border-border rounded-2xl">
              <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
                <CreditCard className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-foreground text-lg mb-2">
                No transactions found
              </h3>
              <p className="text-muted-foreground">
                No payments match your search criteria.
              </p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default PaymentHistory;
