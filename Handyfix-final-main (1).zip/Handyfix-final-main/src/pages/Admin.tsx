import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CheckCircle, XCircle, User, MapPin, Briefcase } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface UnverifiedProvider {
  _id: string;
  userId: {
    _id: string;
    name: string;
    email: string;
    phone: string;
  };
  skills: string[];
  experience: string;
  location: string;
  bio: string;
  createdAt: string;
}

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, token } = useAuth();
  const { toast } = useToast();

  const [providers, setProviders] = useState<UnverifiedProvider[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [approvingId, setApprovingId] = useState<string | null>(null);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    fetchUnverifiedProviders();
  }, [isAuthenticated, navigate, token]);

  const fetchUnverifiedProviders = async () => {
    try {
      if (!token) return;

      const response = await fetch('/api/providers/unverified', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setProviders(data);
      }
    } catch (error) {
      console.error('Error fetching unverified providers:', error);
      toast({
        title: 'Error',
        description: 'Failed to load unverified providers',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveProvider = async (providerId: string) => {
    if (!token) return;

    setApprovingId(providerId);

    try {
      const response = await fetch(`/api/providers/approve/${providerId}`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        setProviders(providers.filter((p) => p._id !== providerId));
        toast({
          title: 'Success',
          description: 'Provider approved successfully',
        });
      }
    } catch (error) {
      console.error('Error approving provider:', error);
      toast({
        title: 'Error',
        description: 'Failed to approve provider',
        variant: 'destructive',
      });
    } finally {
      setApprovingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold text-foreground">Admin Panel</h1>
          <p className="text-sm text-muted-foreground">Manage provider verification requests</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-xl font-bold text-foreground mb-6">
          Pending Verification Requests ({providers.length})
        </h2>

        {isLoading ? (
          <Card className="p-8 text-center border border-border/50">
            <p className="text-muted-foreground">Loading pending requests...</p>
          </Card>
        ) : providers.length === 0 ? (
          <Card className="p-8 text-center border border-border/50">
            <CheckCircle className="w-12 h-12 mx-auto text-green-600 mb-4 opacity-50" />
            <p className="text-muted-foreground">All providers have been verified!</p>
          </Card>
        ) : (
          <div className="grid gap-6">
            {providers.map((provider) => (
              <Card
                key={provider._id}
                className="p-6 border border-border/50 hover:border-primary/50 transition-all"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6 mb-6">
                  {/* Provider Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">
                          {provider.userId.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">{provider.userId.email}</p>
                      </div>
                    </div>

                    <div className="space-y-3 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Briefcase className="w-4 h-4" />
                        <span>Phone: {provider.userId.phone}</span>
                      </div>

                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        <span>Location: {provider.location}</span>
                      </div>

                      <div className="flex items-center gap-2 text-muted-foreground">
                        <span>Experience: {provider.experience}</span>
                      </div>
                    </div>

                    {provider.bio && (
                      <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                        <p className="text-xs text-muted-foreground font-medium mb-1">Bio</p>
                        <p className="text-sm text-foreground">{provider.bio}</p>
                      </div>
                    )}
                  </div>

                  {/* Skills */}
                  <div className="md:min-w-[250px]">
                    <h4 className="font-semibold text-foreground mb-3 text-sm">Skills</h4>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {provider.skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium capitalize"
                        >
                          {skill.replace('_', ' ')}
                        </span>
                      ))}
                    </div>

                    <div className="text-xs text-muted-foreground mb-4">
                      Applied: {new Date(provider.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-6 border-t border-border/30">
                  <Button
                    onClick={() => handleApproveProvider(provider._id)}
                    variant="hero"
                    className="flex-1 gap-2"
                    disabled={approvingId === provider._id}
                  >
                    <CheckCircle className="w-4 h-4" />
                    {approvingId === provider._id ? 'Approving...' : 'Approve'}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    disabled={true}
                  >
                    <XCircle className="w-4 h-4" />
                    Reject (Coming Soon)
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
