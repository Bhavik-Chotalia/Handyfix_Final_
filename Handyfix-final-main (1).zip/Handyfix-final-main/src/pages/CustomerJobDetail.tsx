import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, MapPin, Calendar, DollarSign, Star, Send } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Job {
  _id: string;
  serviceType: string;
  description: string;
  location: string;
  status: string;
  budget?: number;
  actualPrice?: number;
  createdAt: string;
  preferredTime?: string;
  providerId?: {
    _id: string;
    userId: {
      name: string;
      email: string;
      phone: string;
    };
    skills: string[];
    rating: number;
    totalRatings: number;
  };
}

const CustomerJobDetail: React.FC = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, token } = useAuth();
  const { toast } = useToast();

  const [job, setJob] = useState<Job | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    if (jobId) {
      fetchJobDetails();
    }
  }, [isAuthenticated, navigate, jobId, token]);

  const fetchJobDetails = async () => {
    try {
      if (!token) return;

      const response = await fetch(`/api/bookings/${jobId}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setJob(data);
      }
    } catch (error) {
      console.error('Error fetching job details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load job details',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!rating) {
      toast({
        title: 'Error',
        description: 'Please select a rating',
        variant: 'destructive',
      });
      return;
    }

    if (!token || !jobId) return;

    setIsSubmittingReview(true);

    try {
      const response = await fetch(`/api/bookings/${jobId}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          rating,
          comment,
        }),
      });

      if (response.ok) {
        setHasReviewed(true);
        setRating(0);
        setComment('');
        toast({
          title: 'Success',
          description: 'Review submitted successfully',
        });
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit review',
        variant: 'destructive',
      });
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-yellow-100 text-yellow-800';
      case 'in_progress':
        return 'bg-purple-100 text-purple-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading job details...</p>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Job not found</p>
          <Button onClick={() => navigate('/customer')}>Back to Jobs</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <div className="border-b border-border/40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/customer')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground capitalize">{job.serviceType}</h1>
            <p className="text-sm text-muted-foreground">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
                {job.status.replace('_', ' ').toUpperCase()}
              </span>
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Info */}
          <div className="md:col-span-2 space-y-6">
            {/* Job Details */}
            <Card className="p-6 border border-border/50">
              <h2 className="text-lg font-bold text-foreground mb-4">Job Details</h2>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Description</p>
                  <p className="text-foreground">{job.description}</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 pt-4 border-t border-border/30">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Location</p>
                      <p className="text-sm font-medium text-foreground">{job.location}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Requested</p>
                      <p className="text-sm font-medium text-foreground">
                        {new Date(job.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {job.budget && (
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Budget</p>
                        <p className="text-sm font-medium text-foreground">${job.budget}</p>
                      </div>
                    </div>
                  )}

                  {job.actualPrice && (
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">Paid Amount</p>
                        <p className="text-sm font-medium text-foreground">${job.actualPrice}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>

            {/* Provider Info */}
            {job.providerId && (
              <Card className="p-6 border border-border/50">
                <h2 className="text-lg font-bold text-foreground mb-4">Service Provider</h2>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-lg font-semibold text-foreground">
                      {job.providerId.userId.name}
                    </p>
                    <p className="text-sm text-muted-foreground">{job.providerId.userId.email}</p>
                    <p className="text-sm text-muted-foreground">{job.providerId.userId.phone}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(job.providerId!.rating)
                              ? 'fill-yellow-500 text-yellow-500'
                              : 'text-muted-foreground'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {job.providerId.rating.toFixed(1)} ({job.providerId.totalRatings} reviews)
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Skills</p>
                  <div className="flex flex-wrap gap-2">
                    {job.providerId.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium capitalize"
                      >
                        {skill.replace('_', ' ')}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            )}

            {/* Review Section */}
            {job.status === 'completed' && job.providerId && !hasReviewed && (
              <Card className="p-6 border border-border/50">
                <h2 className="text-lg font-bold text-foreground mb-4">Rate & Review</h2>
                <form onSubmit={handleSubmitReview} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      Rate this service
                    </label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="focus:outline-none transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              star <= rating
                                ? 'fill-yellow-500 text-yellow-500'
                                : 'text-muted-foreground'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      Your review (Optional)
                    </label>
                    <textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Share your experience with this service provider..."
                      className="input-modern w-full min-h-24"
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="hero"
                    className="w-full gap-2"
                    disabled={isSubmittingReview}
                  >
                    <Send className="w-4 h-4" />
                    {isSubmittingReview ? 'Submitting...' : 'Submit Review'}
                  </Button>
                </form>
              </Card>
            )}

            {hasReviewed && (
              <Card className="p-6 border border-green-200 bg-green-50">
                <p className="text-green-800">Thank you! Your review has been submitted.</p>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <Card className="p-6 border border-border/50 sticky top-6">
              <h3 className="text-lg font-bold text-foreground mb-4">Status Timeline</h3>
              <div className="space-y-4">
                {[
                  { status: 'requested', label: 'Requested' },
                  { status: 'accepted', label: 'Accepted' },
                  { status: 'in_progress', label: 'In Progress' },
                  { status: 'completed', label: 'Completed' },
                ].map((item, index) => (
                  <div key={item.status} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          ['requested', 'accepted', 'in_progress', 'completed'].indexOf(
                            job.status
                          ) >= index
                            ? 'bg-primary'
                            : 'bg-border'
                        }`}
                      />
                      {index < 3 && (
                        <div
                          className={`w-0.5 h-8 mt-1 ${
                            ['requested', 'accepted', 'in_progress', 'completed'].indexOf(
                              job.status
                            ) > index
                              ? 'bg-primary'
                              : 'bg-border'
                          }`}
                        />
                      )}
                    </div>
                    <div className="pt-1">
                      <p
                        className={`text-sm font-medium ${
                          ['requested', 'accepted', 'in_progress', 'completed'].indexOf(
                            job.status
                          ) >= index
                            ? 'text-foreground'
                            : 'text-muted-foreground'
                        }`}
                      >
                        {item.label}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerJobDetail;
