import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Heart,
  Star,
  MapPin,
  Clock,
  Trash2,
  ShoppingCart,
} from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface SavedService {
  id: number;
  name: string;
  category: string;
  price: number;
  rating: number;
  reviews: number;
  duration: string;
  image: string;
  description: string;
  savedAt: string;
}

const SavedServices: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [savedServices, setSavedServices] = useState<SavedService[]>([
    {
      id: 1,
      name: 'Emergency Plumbing Repair',
      category: 'plumbing',
      price: 6750,
      rating: 4.9,
      reviews: 234,
      duration: '1-2 hours',
      image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=400&h=300&fit=crop',
      description: '24/7 emergency plumbing services for leaks, clogs, and pipe repairs.',
      savedAt: '2024-02-18',
    },
    {
      id: 3,
      name: 'Custom Furniture Building',
      category: 'carpentry',
      price: 18000,
      rating: 4.9,
      reviews: 156,
      duration: '1-2 weeks',
      image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop',
      description: 'Handcrafted custom furniture tailored to your specifications.',
      savedAt: '2024-02-17',
    },
    {
      id: 5,
      name: 'Deep Home Cleaning',
      category: 'cleaning',
      price: 7650,
      rating: 4.8,
      reviews: 312,
      duration: '3-5 hours',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&h=300&fit=crop',
      description: 'Comprehensive deep cleaning service for your entire home.',
      savedAt: '2024-02-16',
    },
  ]);

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    }
  }, [isAuthenticated, navigate]);

  const handleRemoveSaved = (serviceId: number) => {
    setSavedServices(savedServices.filter((service) => service.id !== serviceId));
    toast({
      title: 'Removed',
      description: 'Service removed from saved items.',
    });
  };

  const handleBookService = (serviceId: number) => {
    navigate('/services');
    toast({
      title: 'Ready to Book',
      description: 'Search for this service and book now.',
    });
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4 max-w-5xl">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">
              Saved Services
            </h1>
            <p className="text-muted-foreground">
              {savedServices.length} service{savedServices.length !== 1 ? 's' : ''} saved
            </p>
          </div>

          {/* Services Grid */}
          {savedServices.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedServices.map((service) => (
                <div
                  key={service.id}
                  className="bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/50 transition-all group"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={service.image}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <button
                      onClick={() => handleRemoveSaved(service.id)}
                      className="absolute top-3 right-3 p-2 bg-white rounded-full hover:bg-red-500 hover:text-white transition-all shadow-lg"
                    >
                      <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                    </button>
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-foreground text-lg mb-2 line-clamp-2">
                      {service.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {service.description}
                    </p>

                    <div className="flex items-center justify-between mb-4 text-sm">
                      <span className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="font-medium text-foreground">{service.rating}</span>
                        <span className="text-muted-foreground">({service.reviews})</span>
                      </span>
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        {service.duration}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <span className="text-2xl font-bold text-primary">
                        ₹{service.price.toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {service.category}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleBookService(service.id)}
                        className="flex-1 gap-2"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        Book Now
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleRemoveSaved(service.id)}
                        className="px-3"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <p className="text-xs text-muted-foreground text-center mt-3">
                      Saved {new Date(service.savedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
                <Heart className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-foreground text-lg mb-2">
                No saved services yet
              </h3>
              <p className="text-muted-foreground mb-6">
                Save your favorite services to book them later.
              </p>
              <Button onClick={() => navigate('/services')}>
                Browse Services
              </Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default SavedServices;
