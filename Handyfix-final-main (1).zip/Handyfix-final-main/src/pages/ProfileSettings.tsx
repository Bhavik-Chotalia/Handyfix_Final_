import React, { useState, useRef } from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Camera,
  Save,
  ArrowLeft,
  Key,
  Bell,
  Eye,
  CreditCard,
  HelpCircle,
  Globe,
  Lock,
  LogOut,
} from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

interface SettingsTab {
  id: string;
  label: string;
  icon: React.ReactNode;
}

const ProfileSettings: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<string>('personal');
  const [isLoading, setIsLoading] = useState(false);

  const [personalData, setPersonalData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    bio: '',
  });

  const [addressData, setAddressData] = useState({
    addresses: [
      {
        id: 1,
        label: 'Home',
        street: '',
        city: '',
        state: '',
        zipCode: '',
        isDefault: true,
      },
    ],
  });

  const [paymentData, setPaymentData] = useState({
    savedCards: [],
    defaultPaymentMethod: '',
  });

  const [notificationPreferences, setNotificationPreferences] = useState({
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    bookingUpdates: true,
    promotions: false,
  });

  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: 'private',
    shareData: false,
    allowAnalytics: true,
  });

  const [avatar, setAvatar] = useState<string>(user?.avatar || '');

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    }
  }, [isAuthenticated, navigate]);

  const handlePersonalChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setPersonalData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddressChange = (
    addressId: number,
    field: string,
    value: string
  ) => {
    setAddressData((prev) => ({
      ...prev,
      addresses: prev.addresses.map((addr) =>
        addr.id === addressId ? { ...addr, [field]: value } : addr
      ),
    }));
  };

  const addNewAddress = () => {
    const newId = Math.max(...addressData.addresses.map((a) => a.id), 0) + 1;
    setAddressData((prev) => ({
      ...prev,
      addresses: [
        ...prev.addresses,
        {
          id: newId,
          label: 'New Address',
          street: '',
          city: '',
          state: '',
          zipCode: '',
          isDefault: false,
        },
      ],
    }));
  };

  const removeAddress = (addressId: number) => {
    setAddressData((prev) => ({
      ...prev,
      addresses: prev.addresses.filter((addr) => addr.id !== addressId),
    }));
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSavePersonal = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    toast({
      title: 'Profile Updated',
      description: 'Your personal information has been saved successfully.',
    });
    setIsLoading(false);
  };

  const handleSaveAddresses = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    toast({
      title: 'Addresses Saved',
      description: 'Your addresses have been updated successfully.',
    });
    setIsLoading(false);
  };

  const handleNotificationChange = (key: string) => {
    setNotificationPreferences((prev) => ({
      ...prev,
      [key]: !prev[key as keyof typeof prev],
    }));
  };

  const handlePrivacyChange = (key: string, value: string | boolean) => {
    setPrivacySettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSaveNotifications = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    toast({
      title: 'Preferences Saved',
      description: 'Your notification preferences have been updated.',
    });
    setIsLoading(false);
  };

  const handleSavePrivacy = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    toast({
      title: 'Privacy Settings Saved',
      description: 'Your privacy settings have been updated.',
    });
    setIsLoading(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleChangePassword = async () => {
    // Password change implementation would go here
    toast({
      title: 'Feature Coming Soon',
      description: 'Password change functionality will be available soon.',
    });
  };

  const settingsTabs: SettingsTab[] = [
    { id: 'personal', label: 'Personal Info', icon: <User className="w-4 h-4" /> },
    { id: 'address', label: 'Addresses', icon: <MapPin className="w-4 h-4" /> },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: <Bell className="w-4 h-4" />,
    },
    { id: 'privacy', label: 'Privacy', icon: <Eye className="w-4 h-4" /> },
    { id: 'security', label: 'Security', icon: <Lock className="w-4 h-4" /> },
    { id: 'help', label: 'Help & Support', icon: <HelpCircle className="w-4 h-4" /> },
  ];

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="min-h-screen py-12 bg-background">
        <div className="container mx-auto px-4 max-w-5xl">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">
              Settings
            </h1>
            <p className="text-muted-foreground">
              Manage your profile, preferences, and account settings
            </p>
          </div>

          <div className="flex gap-6">
            {/* Sidebar */}
            <aside className="w-64 flex-shrink-0">
              <div className="bg-card border border-border rounded-2xl p-2 sticky top-24 space-y-2">
                {settingsTabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all text-left ${
                      activeTab === tab.id
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                    }`}
                  >
                    {tab.icon}
                    {tab.label}
                  </button>
                ))}
              </div>
            </aside>

            {/* Content */}
            <div className="flex-1">
              {/* Personal Information */}
              {activeTab === 'personal' && (
                <form onSubmit={handleSavePersonal} className="space-y-6">
                  {/* Avatar Section */}
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-4">
                      Profile Picture
                    </h2>
                    <div className="flex items-center gap-6">
                      <div className="relative">
                        <div
                          className="w-24 h-24 rounded-2xl overflow-hidden bg-muted flex items-center justify-center cursor-pointer group"
                          onClick={handleAvatarClick}
                        >
                          {avatar ? (
                            <img src={avatar} alt="Profile" className="w-full h-full object-cover" />
                          ) : (
                            <User className="w-10 h-10 text-muted-foreground" />
                          )}
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Camera className="w-6 h-6 text-white" />
                          </div>
                        </div>
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleAvatarChange}
                          accept="image/*"
                          className="hidden"
                        />
                      </div>
                      <div>
                        <Button type="button" variant="outline" onClick={handleAvatarClick} className="mb-2">
                          Upload New Photo
                        </Button>
                        <p className="text-sm text-muted-foreground">
                          JPG, PNG or GIF. Max size 2MB.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Personal Details */}
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-4">
                      Personal Details
                    </h2>
                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="fullName" className="flex items-center gap-2">
                          <User className="w-4 h-4 text-muted-foreground" />
                          Full Name
                        </Label>
                        <Input
                          id="fullName"
                          name="fullName"
                          value={personalData.fullName}
                          onChange={handlePersonalChange}
                          placeholder="Enter your full name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-muted-foreground" />
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={personalData.email}
                          onChange={handlePersonalChange}
                          placeholder="Enter your email"
                          disabled
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          Phone Number
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={personalData.phone}
                          onChange={handlePersonalChange}
                          placeholder="Enter your phone number"
                        />
                      </div>
                    </div>

                    <div className="space-y-2 mt-6">
                      <Label htmlFor="bio">About Me</Label>
                      <Textarea
                        id="bio"
                        name="bio"
                        value={personalData.bio}
                        onChange={handlePersonalChange}
                        placeholder="Tell us a little about yourself..."
                        rows={4}
                        className="resize-none"
                      />
                      <p className="text-sm text-muted-foreground">
                        Max 300 characters. This appears on your public profile.
                      </p>
                    </div>
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end">
                    <Button type="submit" disabled={isLoading} className="gap-2">
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}

              {/* Addresses */}
              {activeTab === 'address' && (
                <form onSubmit={handleSaveAddresses} className="space-y-6">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-semibold text-foreground text-lg">
                        Saved Addresses
                      </h2>
                      <Button type="button" variant="outline" onClick={addNewAddress}>
                        + Add New Address
                      </Button>
                    </div>

                    <div className="space-y-6">
                      {addressData.addresses.map((address, index) => (
                        <div
                          key={address.id}
                          className="border border-border rounded-xl p-4 space-y-4"
                        >
                          <div className="flex items-center justify-between">
                            <Input
                              value={address.label}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'label', e.target.value)
                              }
                              placeholder="Address label (e.g., Home, Office)"
                              className="max-w-xs"
                            />
                            {addressData.addresses.length > 1 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => removeAddress(address.id)}
                                className="text-destructive"
                              >
                                Remove
                              </Button>
                            )}
                          </div>

                          <div className="grid gap-4 md:grid-cols-2">
                            <Input
                              value={address.street}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'street', e.target.value)
                              }
                              placeholder="Street Address"
                            />
                            <Input
                              value={address.city}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'city', e.target.value)
                              }
                              placeholder="City"
                            />
                            <Input
                              value={address.state}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'state', e.target.value)
                              }
                              placeholder="State"
                            />
                            <Input
                              value={address.zipCode}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'zipCode', e.target.value)
                              }
                              placeholder="ZIP Code"
                            />
                          </div>

                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={address.isDefault}
                              onChange={(e) =>
                                handleAddressChange(address.id, 'isDefault', e.target.checked ? 'true' : 'false')
                              }
                              className="w-4 h-4 rounded"
                            />
                            <span className="text-sm text-muted-foreground">
                              Set as default address
                            </span>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isLoading} className="gap-2">
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          Save Addresses
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}

              {/* Notifications */}
              {activeTab === 'notifications' && (
                <form onSubmit={handleSaveNotifications} className="space-y-6">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-6">
                      Notification Preferences
                    </h2>

                    <div className="space-y-4">
                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Email Notifications</p>
                          <p className="text-sm text-muted-foreground">
                            Receive updates via email
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={notificationPreferences.emailNotifications}
                          onChange={() => handleNotificationChange('emailNotifications')}
                          className="w-5 h-5"
                        />
                      </label>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">SMS Notifications</p>
                          <p className="text-sm text-muted-foreground">
                            Receive updates via SMS
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={notificationPreferences.smsNotifications}
                          onChange={() => handleNotificationChange('smsNotifications')}
                          className="w-5 h-5"
                        />
                      </label>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Push Notifications</p>
                          <p className="text-sm text-muted-foreground">
                            Receive push notifications
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={notificationPreferences.pushNotifications}
                          onChange={() => handleNotificationChange('pushNotifications')}
                          className="w-5 h-5"
                        />
                      </label>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Booking Updates</p>
                          <p className="text-sm text-muted-foreground">
                            Get notified about your bookings
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={notificationPreferences.bookingUpdates}
                          onChange={() => handleNotificationChange('bookingUpdates')}
                          className="w-5 h-5"
                        />
                      </label>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Promotions</p>
                          <p className="text-sm text-muted-foreground">
                            Receive promotional offers and deals
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={notificationPreferences.promotions}
                          onChange={() => handleNotificationChange('promotions')}
                          className="w-5 h-5"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isLoading} className="gap-2">
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          Save Preferences
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}

              {/* Privacy Settings */}
              {activeTab === 'privacy' && (
                <form onSubmit={handleSavePrivacy} className="space-y-6">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-6">
                      Privacy Settings
                    </h2>

                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-3">
                          Profile Visibility
                        </label>
                        <div className="space-y-2">
                          {[
                            { value: 'private', label: 'Private - Only visible to you' },
                            {
                              value: 'friends',
                              label: 'Friends Only - Visible to friends',
                            },
                            { value: 'public', label: 'Public - Visible to everyone' },
                          ].map((option) => (
                            <label key={option.value} className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 cursor-pointer">
                              <input
                                type="radio"
                                name="visibility"
                                value={option.value}
                                checked={privacySettings.profileVisibility === option.value}
                                onChange={(e) =>
                                  handlePrivacyChange('profileVisibility', e.target.value)
                                }
                                className="w-4 h-4"
                              />
                              <span className="text-sm text-foreground">{option.label}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Share Data for Analytics</p>
                          <p className="text-sm text-muted-foreground">
                            Help us improve by sharing usage data
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={privacySettings.allowAnalytics}
                          onChange={(e) =>
                            handlePrivacyChange('allowAnalytics', e.target.checked)
                          }
                          className="w-5 h-5"
                        />
                      </label>

                      <label className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                        <div>
                          <p className="font-medium text-foreground">Third-Party Data Sharing</p>
                          <p className="text-sm text-muted-foreground">
                            Allow sharing data with trusted partners
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={privacySettings.shareData}
                          onChange={(e) =>
                            handlePrivacyChange('shareData', e.target.checked)
                          }
                          className="w-5 h-5"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isLoading} className="gap-2">
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          Save Settings
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}

              {/* Security Settings */}
              {activeTab === 'security' && (
                <div className="space-y-6">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-6">
                      Security Settings
                    </h2>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                        <div>
                          <p className="font-medium text-foreground flex items-center gap-2">
                            <Key className="w-4 h-4" />
                            Password
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Change your password
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleChangePassword}
                        >
                          Change
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                        <div>
                          <p className="font-medium text-foreground flex items-center gap-2">
                            <Lock className="w-4 h-4" />
                            Two-Factor Authentication
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Add an extra layer of security
                          </p>
                        </div>
                        <Button type="button" variant="outline">
                          Enable
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-4">
                      Active Sessions
                    </h2>
                    <p className="text-muted-foreground text-sm mb-4">
                      Manage your active sessions and logged-in devices
                    </p>
                    <Button variant="outline" className="w-full">
                      View All Sessions
                    </Button>
                  </div>
                </div>
              )}

              {/* Help & Support */}
              {activeTab === 'help' && (
                <div className="space-y-6">
                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-6">
                      Frequently Asked Questions
                    </h2>

                    <div className="space-y-4">
                      {[
                        {
                          q: 'How do I book a service?',
                          a: 'Browse services, select one, choose your date/time, and proceed to checkout.',
                        },
                        {
                          q: 'Can I cancel a booking?',
                          a: 'Yes, you can cancel bookings up to 24 hours before the scheduled time.',
                        },
                        {
                          q: 'What payment methods do you accept?',
                          a: 'We accept all major credit cards, debit cards, UPI, and digital wallets.',
                        },
                        {
                          q: 'How do I report an issue?',
                          a: 'Contact our support team through the Help section in the app.',
                        },
                      ].map((faq, index) => (
                        <div
                          key={index}
                          className="p-4 border border-border rounded-lg"
                        >
                          <p className="font-medium text-foreground mb-2">{faq.q}</p>
                          <p className="text-sm text-muted-foreground">{faq.a}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-card border border-border rounded-2xl p-6">
                    <h2 className="font-semibold text-foreground text-lg mb-4">
                      Contact Support
                    </h2>
                    <div className="space-y-3">
                      <p className="text-sm text-muted-foreground">
                        Email: support@handyfix.com
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Phone: +91 1800-123-4567
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Hours: Monday - Friday, 9 AM - 6 PM IST
                      </p>
                      <Button variant="outline" className="w-full mt-4">
                        Chat with Support
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Logout Button */}
              <div className="mt-8 pt-6 border-t border-border">
                <Button
                  onClick={handleLogout}
                  variant="destructive"
                  className="gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProfileSettings;
