import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Customer from "./pages/Customer";
import CustomerJobDetail from "./pages/CustomerJobDetail";
import Services from "./pages/Services";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Emergency from "./pages/Emergency";
import Profile from "./pages/Profile";
import UserProfile from "./pages/UserProfile";
import ProfileSettings from "./pages/ProfileSettings";
import MyBookings from "./pages/MyBookings";
import SavedServices from "./pages/SavedServices";
import PaymentHistory from "./pages/PaymentHistory";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/dashboard" element={<Dashboard />} />

              {/* User Routes - Protected */}
              <Route
                path="/user/dashboard"
                element={
                  <ProtectedRoute requiredRole="user">
                    <Customer />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/customer"
                element={
                  <ProtectedRoute requiredRole="user">
                    <Customer />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/customer/job/:jobId"
                element={
                  <ProtectedRoute requiredRole="user">
                    <CustomerJobDetail />
                  </ProtectedRoute>
                }
              />


              {/* Public Routes */}
              <Route path="/services" element={<Services />} />
              <Route path="/providers" element={<Navigate to="/services" replace />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/emergency" element={<Emergency />} />
              <Route path="/profile" element={<Profile />} />

              {/* Protected Profile Route */}
              <Route
                path="/user/profile"
                element={
                  <ProtectedRoute requiredRole="user">
                    <UserProfile />
                  </ProtectedRoute>
                }
              />

              {/* Settings Route */}
              <Route
                path="/settings"
                element={
                  <ProtectedRoute requiredRole="user">
                    <ProfileSettings />
                  </ProtectedRoute>
                }
              />

              {/* User Feature Routes */}
              <Route
                path="/my-bookings"
                element={
                  <ProtectedRoute requiredRole="user">
                    <MyBookings />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/saved-services"
                element={
                  <ProtectedRoute requiredRole="user">
                    <SavedServices />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/payments"
                element={
                  <ProtectedRoute requiredRole="user">
                    <PaymentHistory />
                  </ProtectedRoute>
                }
              />

              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
