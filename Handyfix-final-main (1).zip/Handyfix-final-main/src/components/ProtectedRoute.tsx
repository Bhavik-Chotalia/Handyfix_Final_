import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: 'user' | 'service_provider' | 'admin';
  requireAuth?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRole,
  requireAuth = true,
}) => {
  const { isAuthenticated, isGuest, userRole, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // If guest mode, redirect to login with return URL
  if (isGuest && requireAuth) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // If not authenticated and auth is required, redirect to login
  if (!isAuthenticated && requireAuth) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // If role is specified, check if user has the required role
  if (isAuthenticated && requiredRole && userRole !== requiredRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
