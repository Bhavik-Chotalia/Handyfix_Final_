const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const authMiddleware = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/authMiddleware');

// Customer routes - only users can create bookings and view their history
router.post('/request', authMiddleware, requireRole(['user']), bookingController.createServiceRequest);
router.get('/my-jobs', authMiddleware, requireRole(['user']), bookingController.getCustomerJobs);
router.get('/history', authMiddleware, requireRole(['user']), bookingController.getServiceHistory);
router.get('/:jobId', bookingController.getJobDetails);

// Provider routes - only service_providers can manage jobs
router.get('/requests/incoming', authMiddleware, requireRole(['service_provider']), bookingController.getIncomingRequests);
router.post('/:jobId/accept', authMiddleware, requireRole(['service_provider']), bookingController.acceptJob);
router.post('/:jobId/reject', authMiddleware, requireRole(['service_provider']), bookingController.rejectJob);
router.get('/provider/jobs', authMiddleware, requireRole(['service_provider']), bookingController.getProviderJobs);
router.put('/:jobId/status', authMiddleware, requireRole(['service_provider']), bookingController.updateJobStatus);

// Review routes - only users can submit reviews
router.post('/:jobId/review', authMiddleware, requireRole(['user']), bookingController.submitReview);
router.get('/reviews/:providerId', bookingController.getProviderReviews);

// Earnings - only providers can view earnings
router.get('/provider/earnings', authMiddleware, requireRole(['service_provider']), bookingController.getEarningsSummary);

module.exports = router;
