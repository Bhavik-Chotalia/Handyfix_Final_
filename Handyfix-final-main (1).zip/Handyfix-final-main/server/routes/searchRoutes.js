const express = require('express');
const router = express.Router();
const searchController = require('../controllers/searchController');
const authMiddleware = require('../middleware/authMiddleware');

// Public search routes (no auth required)
router.get('/providers', searchController.searchProviders);
router.get('/providers/:providerId', searchController.getProviderDetails);
router.get('/categories', searchController.getServiceCategories);
router.get('/locations', searchController.getAvailableLocations);

// Protected availability routes
router.get('/availability/:providerId', searchController.getAvailability);
router.put('/availability', authMiddleware, searchController.updateAvailability);
router.post('/availability', authMiddleware, searchController.setAvailability);

module.exports = router;
