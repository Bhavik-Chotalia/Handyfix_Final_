const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const authMiddleware = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/authMiddleware');

// All admin routes require admin role
router.use(authMiddleware);
router.use(requireRole(['admin']));

// User management
router.get('/users', adminController.getAllUsers);
router.get('/users/:userId', adminController.getUserDetails);
router.put('/users/:userId/toggle-block', adminController.toggleUserBlock);

// Provider management
router.get('/providers', adminController.getAllProviders);
router.get('/providers/unverified', adminController.getUnverifiedProviders);
router.put('/providers/:providerId/verify', adminController.verifyProvider);
router.delete('/providers/:providerId/reject', adminController.rejectProvider);

// Booking management
router.get('/bookings', adminController.getAllBookings);

// Analytics
router.get('/analytics', adminController.getAnalytics);

module.exports = router;
