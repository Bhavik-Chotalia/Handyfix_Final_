const express = require('express');
const router = express.Router();
const providerController = require('../controllers/providerController');
const authMiddleware = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/authMiddleware');

// Provider routes
router.post('/register', authMiddleware, requireRole(['service_provider']), providerController.registerProvider);
router.get('/me', authMiddleware, requireRole(['service_provider']), providerController.getMyProviderProfile);
router.get('/profile/:providerId', providerController.getProviderProfile);
router.put('/profile', authMiddleware, requireRole(['service_provider']), providerController.updateProviderProfile);
router.put('/status', authMiddleware, requireRole(['service_provider']), providerController.toggleOnlineStatus);
router.get('/nearby', providerController.getNearbyProviders);

// Admin routes - only admins can view and approve providers
router.get('/unverified', authMiddleware, requireRole(['admin']), providerController.getUnverifiedProviders);
router.put('/approve/:providerId', authMiddleware, requireRole(['admin']), providerController.approveProvider);

module.exports = router;
