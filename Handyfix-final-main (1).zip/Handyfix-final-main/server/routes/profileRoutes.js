const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const authMiddleware = require('../middleware/authMiddleware');

// Get current authenticated user's profile
router.get('/me', authMiddleware, profileController.getCurrentUserProfile);

// Update current user's profile
router.put('/me', authMiddleware, profileController.updateUserProfile);

// Get any user's public profile
router.get('/:userId', profileController.getUserProfile);

module.exports = router;
