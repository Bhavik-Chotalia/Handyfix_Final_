const User = require('../models/User');
const Provider = require('../models/Provider');
const Job = require('../models/Job');
const Review = require('../models/Review');

// Get all users
exports.getAllUsers = async (req, res) => {
    try {
        const { role, isBlocked } = req.query;

        let query = {};
        if (role) {
            query.role = role;
        }
        if (isBlocked !== undefined) {
            query.isBlocked = isBlocked === 'true';
        }

        const users = await User.find(query)
            .select('-password')
            .sort({ createdAt: -1 });

        res.json(users);
    } catch (error) {
        console.error('Get All Users Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user details
exports.getUserDetails = async (req, res) => {
    try {
        const { userId } = req.params;

        const user = await User.findById(userId).select('-password');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(user);
    } catch (error) {
        console.error('Get User Details Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Block or unblock user
exports.toggleUserBlock = async (req, res) => {
    try {
        const { userId } = req.params;
        const { isBlocked } = req.body;

        const user = await User.findByIdAndUpdate(
            userId,
            { isBlocked },
            { new: true }
        ).select('-password');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({
            message: isBlocked ? 'User blocked' : 'User unblocked',
            user,
        });
    } catch (error) {
        console.error('Toggle User Block Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all unverified providers
exports.getUnverifiedProviders = async (req, res) => {
    try {
        const providers = await Provider.find({ isVerified: false })
            .populate('userId', 'name email phone')
            .sort({ createdAt: -1 });

        res.json(providers);
    } catch (error) {
        console.error('Get Unverified Providers Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all verified providers
exports.getAllProviders = async (req, res) => {
    try {
        const { isVerified } = req.query;

        let query = {};
        if (isVerified !== undefined) {
            query.isVerified = isVerified === 'true';
        }

        const providers = await Provider.find(query)
            .populate('userId', 'name email phone')
            .sort({ createdAt: -1 });

        res.json(providers);
    } catch (error) {
        console.error('Get All Providers Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Verify provider
exports.verifyProvider = async (req, res) => {
    try {
        const { providerId } = req.params;

        const provider = await Provider.findByIdAndUpdate(
            providerId,
            { isVerified: true },
            { new: true }
        ).populate('userId', 'name email phone');

        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json({
            message: 'Provider verified',
            provider,
        });
    } catch (error) {
        console.error('Verify Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Reject provider
exports.rejectProvider = async (req, res) => {
    try {
        const { providerId } = req.params;

        const provider = await Provider.findByIdAndDelete(providerId);

        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json({ message: 'Provider rejected and deleted' });
    } catch (error) {
        console.error('Reject Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all bookings
exports.getAllBookings = async (req, res) => {
    try {
        const { status } = req.query;

        let query = {};
        if (status) {
            query.status = status;
        }

        const bookings = await Job.find(query)
            .populate('customerId', 'name email')
            .populate('providerId', 'userId')
            .sort({ createdAt: -1 });

        res.json(bookings);
    } catch (error) {
        console.error('Get All Bookings Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get analytics dashboard
exports.getAnalytics = async (req, res) => {
    try {
        const totalUsers = await User.countDocuments({ role: 'user' });
        const totalProviders = await User.countDocuments({ role: 'service_provider' });
        const verifiedProviders = await Provider.countDocuments({ isVerified: true });
        const totalBookings = await Job.countDocuments();
        const completedBookings = await Job.countDocuments({ status: 'completed' });
        const pendingBookings = await Job.countDocuments({ status: 'requested' });

        // Revenue calculation (total earnings from completed jobs)
        const completedJobs = await Job.find({ status: 'completed' });
        const totalRevenue = completedJobs.reduce((sum, job) => sum + (job.actualPrice || 0), 0);

        // Average rating
        const reviews = await Review.find();
        const avgRating = reviews.length > 0
            ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(2)
            : 0;

        res.json({
            totalUsers,
            totalProviders,
            verifiedProviders,
            totalBookings,
            completedBookings,
            pendingBookings,
            totalRevenue,
            avgRating,
        });
    } catch (error) {
        console.error('Get Analytics Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
