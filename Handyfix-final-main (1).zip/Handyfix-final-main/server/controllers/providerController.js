const Provider = require('../models/Provider');
const User = require('../models/User');

// Register as provider (first time setup)
exports.registerProvider = async (req, res) => {
    const { skills, experience, location, bio } = req.body;
    const userId = req.userId;

    try {
        // Check if already registered as provider
        const existingProvider = await Provider.findOne({ userId });
        if (existingProvider) {
            return res.status(400).json({ message: 'Already registered as provider' });
        }

        const newProvider = new Provider({
            userId,
            skills: skills || [],
            experience: experience || '',
            location,
            bio: bio || '',
            isVerified: false, // Requires admin approval
            isOnline: false,
        });

        await newProvider.save();

        res.status(201).json({
            message: 'Provider registration initiated. Awaiting verification.',
            provider: {
                id: newProvider._id,
                userId: newProvider.userId,
                skills: newProvider.skills,
                isVerified: newProvider.isVerified,
            },
        });

    } catch (error) {
        console.error('Provider Registration Error:', error);
        res.status(500).json({ message: 'Server error during provider registration' });
    }
};

// Get provider profile
exports.getProviderProfile = async (req, res) => {
    const { providerId } = req.params;

    try {
        const provider = await Provider.findById(providerId).populate('userId', 'name email phone avatar');
        
        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json(provider);
    } catch (error) {
        console.error('Get Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get current user's provider profile
exports.getMyProviderProfile = async (req, res) => {
    const userId = req.userId;

    try {
        const provider = await Provider.findOne({ userId }).populate('userId', 'name email phone avatar');
        
        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        res.json(provider);
    } catch (error) {
        console.error('Get My Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Toggle online/offline status
exports.toggleOnlineStatus = async (req, res) => {
    const { isOnline } = req.body;
    const userId = req.userId;

    try {
        const provider = await Provider.findOneAndUpdate(
            { userId },
            { isOnline },
            { new: true }
        );

        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        res.json({
            message: isOnline ? 'You are now online' : 'You are now offline',
            provider: {
                id: provider._id,
                isOnline: provider.isOnline,
            },
        });
    } catch (error) {
        console.error('Toggle Status Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all verified nearby providers
exports.getNearbyProviders = async (req, res) => {
    const { latitude, longitude, serviceType } = req.query;

    try {
        let query = { isVerified: true, isOnline: true };

        if (serviceType) {
            query.skills = { $in: [serviceType] };
        }

        const providers = await Provider.find(query)
            .populate('userId', 'name email phone avatar')
            .sort({ rating: -1 });

        res.json(providers);
    } catch (error) {
        console.error('Get Nearby Providers Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update provider profile
exports.updateProviderProfile = async (req, res) => {
    const { skills, experience, location, bio } = req.body;
    const userId = req.userId;

    try {
        const provider = await Provider.findOneAndUpdate(
            { userId },
            {
                skills: skills || undefined,
                experience: experience || undefined,
                location: location || undefined,
                bio: bio || undefined,
            },
            { new: true }
        );

        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        res.json({
            message: 'Provider profile updated',
            provider,
        });
    } catch (error) {
        console.error('Update Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Admin: Approve provider
exports.approveProvider = async (req, res) => {
    const { providerId } = req.params;

    try {
        const provider = await Provider.findByIdAndUpdate(
            providerId,
            { isVerified: true },
            { new: true }
        );

        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json({
            message: 'Provider approved successfully',
            provider,
        });
    } catch (error) {
        console.error('Approve Provider Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all unverified providers (for admin)
exports.getUnverifiedProviders = async (req, res) => {
    try {
        const providers = await Provider.find({ isVerified: false })
            .populate('userId', 'name email phone')
            .sort({ createdAt: -1 });

        res.json(providers);
    } catch (error) {
        console.error('Get Unverified Providers Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
