const Provider = require('../models/Provider');
const User = require('../models/User');
const Job = require('../models/Job');

// Search providers by category, location, rating, availability
exports.searchProviders = async (req, res) => {
    try {
        const { category, location, minRating, isOnline } = req.query;

        let query = { isVerified: true };

        // Filter by category/service
        if (category) {
            query.skills = { $in: [category] };
        }

        // Filter by location (contains search)
        if (location) {
            query.location = { $regex: location, $options: 'i' };
        }

        // Filter by minimum rating
        if (minRating) {
            query.rating = { $gte: parseFloat(minRating) };
        }

        // Filter by availability
        if (isOnline === 'true') {
            query.isOnline = true;
        }

        const providers = await Provider.find(query)
            .populate('userId', 'name email phone avatar')
            .sort({ rating: -1 });

        res.json(providers);
    } catch (error) {
        console.error('Search Providers Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get provider by ID with full details
exports.getProviderDetails = async (req, res) => {
    try {
        const { providerId } = req.params;

        const provider = await Provider.findById(providerId)
            .populate('userId', 'name email phone avatar');

        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json(provider);
    } catch (error) {
        console.error('Get Provider Details Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all available service categories
exports.getServiceCategories = async (req, res) => {
    try {
        const categories = await Provider.distinct('skills');
        res.json(categories);
    } catch (error) {
        console.error('Get Categories Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get available locations
exports.getAvailableLocations = async (req, res) => {
    try {
        const locations = await Provider.distinct('location');
        res.json(locations);
    } catch (error) {
        console.error('Get Locations Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update provider availability (online/offline)
exports.updateAvailability = async (req, res) => {
    try {
        const userId = req.userId;
        const { isOnline } = req.body;

        const provider = await Provider.findOneAndUpdate(
            { userId },
            { isOnline },
            { new: true }
        );

        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        res.json({
            message: 'Availability updated',
            isOnline: provider.isOnline,
        });
    } catch (error) {
        console.error('Update Availability Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get provider's availability schedule
exports.getAvailability = async (req, res) => {
    try {
        const { providerId } = req.params;

        const provider = await Provider.findById(providerId).select('availability isOnline');

        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        res.json({
            isOnline: provider.isOnline,
            availability: provider.availability || [],
        });
    } catch (error) {
        console.error('Get Availability Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Set provider's availability schedule
exports.setAvailability = async (req, res) => {
    try {
        const userId = req.userId;
        const { availability } = req.body;

        const provider = await Provider.findOneAndUpdate(
            { userId },
            { availability },
            { new: true }
        );

        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        res.json({
            message: 'Availability updated',
            availability: provider.availability,
        });
    } catch (error) {
        console.error('Set Availability Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
