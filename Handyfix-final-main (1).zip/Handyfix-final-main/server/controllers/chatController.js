const Job = require('../models/Job');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const User = require('../models/User');
const Provider = require('../models/Provider');

// Get all conversations for authenticated user
exports.getConversations = async (req, res) => {
    try {
        const userId = req.userId;

        const conversations = await Conversation.find({
            $or: [{ customerId: userId }, { providerId: userId }],
        })
            .populate('jobId', 'serviceType status')
            .populate('customerId', 'name avatar')
            .populate('providerId', 'name avatar')
            .sort({ lastMessageAt: -1 });

        res.json(conversations);
    } catch (error) {
        console.error('Get Conversations Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get messages for a specific conversation
exports.getMessages = async (req, res) => {
    try {
        const { conversationId } = req.params;
        const userId = req.userId;

        // Verify user is part of this conversation
        const conversation = await Conversation.findById(conversationId);
        if (!conversation) {
            return res.status(404).json({ message: 'Conversation not found' });
        }

        const isParticipant =
            conversation.customerId.toString() === userId ||
            conversation.providerId.toString() === userId;

        if (!isParticipant) {
            return res.status(403).json({ message: 'Access denied' });
        }

        const messages = await Message.find({ conversationId })
            .populate('senderId', 'name avatar')
            .sort({ createdAt: 1 });

        // Mark messages as read
        await Message.updateMany(
            { conversationId, senderId: { $ne: userId }, isRead: false },
            { isRead: true }
        );

        res.json(messages);
    } catch (error) {
        console.error('Get Messages Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Send message in a conversation
exports.sendMessage = async (req, res) => {
    try {
        const { conversationId } = req.params;
        const { message: messageText } = req.body;
        const senderId = req.userId;

        if (!messageText || messageText.trim() === '') {
            return res.status(400).json({ message: 'Message cannot be empty' });
        }

        // Verify conversation exists and user is part of it
        const conversation = await Conversation.findById(conversationId);
        if (!conversation) {
            return res.status(404).json({ message: 'Conversation not found' });
        }

        const isParticipant =
            conversation.customerId.toString() === senderId ||
            conversation.providerId.toString() === senderId;

        if (!isParticipant) {
            return res.status(403).json({ message: 'Access denied' });
        }

        // Verify booking is accepted (chat only allowed after acceptance)
        const job = await Job.findById(conversation.jobId);
        if (!job || job.status === 'pending' || job.status === 'requested') {
            return res.status(403).json({ message: 'Chat not allowed until job is accepted' });
        }

        // Create and save message
        const newMessage = new Message({
            conversationId,
            senderId,
            message: messageText,
        });

        await newMessage.save();

        // Update conversation's last message
        await Conversation.findByIdAndUpdate(conversationId, {
            lastMessage: messageText,
            lastMessageAt: new Date(),
        });

        res.status(201).json({
            message: 'Message sent',
            data: await newMessage.populate('senderId', 'name avatar'),
        });
    } catch (error) {
        console.error('Send Message Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Create conversation (called when job is accepted)
exports.createConversation = async (req, res) => {
    try {
        const { jobId } = req.body;
        const userId = req.userId;

        // Verify job exists
        const job = await Job.findById(jobId).populate('providerId');
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        // Check if conversation already exists
        const existingConversation = await Conversation.findOne({ jobId });
        if (existingConversation) {
            return res.status(400).json({ message: 'Conversation already exists' });
        }

        // Get provider user ID
        const provider = await Provider.findById(job.providerId);
        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }

        // Create conversation
        const conversation = new Conversation({
            jobId,
            customerId: job.customerId,
            providerId: provider.userId,
        });

        await conversation.save();

        res.status(201).json({
            message: 'Conversation created',
            conversation,
        });
    } catch (error) {
        console.error('Create Conversation Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
