const User = require('../models/User');
const Provider = require('../models/Provider');

// Get current user's profile
exports.getCurrentUserProfile = async (req, res) => {
    try {
        const userId = req.userId;

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // If user is a provider, also fetch provider profile
        let providerProfile = null;
        if (user.role === 'service_provider') {
            providerProfile = await Provider.findOne({ userId });
        }

        res.json({
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                avatar: user.avatar,
                role: user.role,
                isVerified: user.isVerified,
                isBlocked: user.isBlocked,
                createdAt: user.createdAt,
            },
            provider: providerProfile,
        });
    } catch (error) {
        console.error('Get Profile Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update user profile
exports.updateUserProfile = async (req, res) => {
    try {
        const userId = req.userId;
        const { name, phone, avatar } = req.body;

        const updateData = {};
        if (name) updateData.name = name;
        if (phone) updateData.phone = phone;
        if (avatar) updateData.avatar = avatar;

        const user = await User.findByIdAndUpdate(
            userId,
            updateData,
            { new: true }
        );

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({
            message: 'Profile updated',
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                avatar: user.avatar,
                role: user.role,
            },
        });
    } catch (error) {
        console.error('Update Profile Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user by ID (for other users viewing profile)
exports.getUserProfile = async (req, res) => {
    try {
        const { userId } = req.params;

        const user = await User.findById(userId).select('-password -isBlocked');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // If provider, get provider profile
        let providerProfile = null;
        if (user.role === 'service_provider') {
            providerProfile = await Provider.findOne({ userId });
        }

        res.json({
            user,
            provider: providerProfile,
        });
    } catch (error) {
        console.error('Get User Profile Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
