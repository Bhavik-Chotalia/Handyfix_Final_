const Job = require('../models/Job');
const Provider = require('../models/Provider');
const Review = require('../models/Review');
const Conversation = require('../models/Conversation');

// Create service request (customer)
exports.createServiceRequest = async (req, res) => {
    const { serviceType, description, location, preferredTime, budget } = req.body;
    const customerId = req.userId;

    try {
        const newJob = new Job({
            customerId,
            serviceType,
            description,
            location,
            preferredTime: preferredTime ? new Date(preferredTime) : null,
            budget: budget || null,
            status: 'requested',
        });

        await newJob.save();

        res.status(201).json({
            message: 'Service request created',
            job: newJob,
        });
    } catch (error) {
        console.error('Create Service Request Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get all service requests for customer
exports.getCustomerJobs = async (req, res) => {
    const customerId = req.userId;

    try {
        const jobs = await Job.find({ customerId })
            .populate('providerId', 'userId skills rating')
            .sort({ createdAt: -1 });

        res.json(jobs);
    } catch (error) {
        console.error('Get Customer Jobs Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get single job details
exports.getJobDetails = async (req, res) => {
    const { jobId } = req.params;

    try {
        const job = await Job.findById(jobId)
            .populate('customerId', 'name email phone')
            .populate('providerId', 'userId skills rating');

        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        res.json(job);
    } catch (error) {
        console.error('Get Job Details Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get incoming requests for provider
exports.getIncomingRequests = async (req, res) => {
    const userId = req.userId;

    try {
        // Get provider profile
        const provider = await Provider.findOne({ userId });
        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        // Get jobs matching provider's skills
        const jobs = await Job.find({
            serviceType: { $in: provider.skills },
            status: 'requested',
            providerId: null, // Not yet assigned to anyone
        })
            .populate('customerId', 'name email phone')
            .sort({ createdAt: -1 });

        res.json(jobs);
    } catch (error) {
        console.error('Get Incoming Requests Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Accept job request
exports.acceptJob = async (req, res) => {
    const { jobId } = req.params;
    const userId = req.userId;

    try {
        const provider = await Provider.findOne({ userId });
        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        if (!provider.isVerified) {
            return res.status(403).json({ message: 'You are not verified to accept jobs' });
        }

        const job = await Job.findByIdAndUpdate(
            jobId,
            { providerId: provider._id, status: 'accepted' },
            { new: true }
        );

        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        // Create conversation for chat
        const existingConversation = await Conversation.findOne({ jobId });
        if (!existingConversation) {
            const conversation = new Conversation({
                jobId,
                customerId: job.customerId,
                providerId: userId,
            });
            await conversation.save();
        }

        res.json({
            message: 'Job accepted',
            job,
        });
    } catch (error) {
        console.error('Accept Job Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Reject job request
exports.rejectJob = async (req, res) => {
    const { jobId } = req.params;

    try {
        const job = await Job.findByIdAndUpdate(
            jobId,
            { status: 'cancelled' },
            { new: true }
        );

        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        res.json({
            message: 'Job rejected',
            job,
        });
    } catch (error) {
        console.error('Reject Job Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get provider's active jobs
exports.getProviderJobs = async (req, res) => {
    const userId = req.userId;

    try {
        const provider = await Provider.findOne({ userId });
        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        const jobs = await Job.find({ providerId: provider._id })
            .populate('customerId', 'name email phone')
            .sort({ createdAt: -1 });

        res.json(jobs);
    } catch (error) {
        console.error('Get Provider Jobs Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update job status
exports.updateJobStatus = async (req, res) => {
    const { jobId } = req.params;
    const { status, actualPrice } = req.body;

    try {
        const updateData = { status };
        if (actualPrice !== undefined) {
            updateData.actualPrice = actualPrice;
        }

        const job = await Job.findByIdAndUpdate(jobId, updateData, { new: true });

        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        // Update provider earnings if job is completed
        if (status === 'completed' && job.actualPrice) {
            await Provider.findByIdAndUpdate(
                job.providerId,
                { $inc: { totalEarnings: job.actualPrice } }
            );
        }

        res.json({
            message: 'Job status updated',
            job,
        });
    } catch (error) {
        console.error('Update Job Status Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Submit review for completed job
exports.submitReview = async (req, res) => {
    const { jobId } = req.params;
    const { rating, comment } = req.body;
    const customerId = req.userId;

    try {
        const job = await Job.findById(jobId);
        if (!job) {
            return res.status(404).json({ message: 'Job not found' });
        }

        if (job.customerId.toString() !== customerId) {
            return res.status(403).json({ message: 'Unauthorized' });
        }

        // Check if review already exists
        const existingReview = await Review.findOne({ jobId });
        if (existingReview) {
            return res.status(400).json({ message: 'Review already submitted for this job' });
        }

        const newReview = new Review({
            jobId,
            customerId,
            providerId: job.providerId,
            rating,
            comment: comment || '',
        });

        await newReview.save();

        // Update provider rating
        const reviews = await Review.find({ providerId: job.providerId });
        const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;

        await Provider.findByIdAndUpdate(job.providerId, {
            rating: avgRating,
            totalRatings: reviews.length,
        });

        res.status(201).json({
            message: 'Review submitted',
            review: newReview,
        });
    } catch (error) {
        console.error('Submit Review Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get reviews for a provider
exports.getProviderReviews = async (req, res) => {
    const { providerId } = req.params;

    try {
        const reviews = await Review.find({ providerId })
            .populate('customerId', 'name')
            .populate('jobId', 'serviceType')
            .sort({ createdAt: -1 });

        res.json(reviews);
    } catch (error) {
        console.error('Get Provider Reviews Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get service history for customer
exports.getServiceHistory = async (req, res) => {
    const customerId = req.userId;

    try {
        const jobs = await Job.find({
            customerId,
            status: { $in: ['completed', 'cancelled'] },
        })
            .populate('providerId', 'userId skills rating')
            .sort({ createdAt: -1 });

        res.json(jobs);
    } catch (error) {
        console.error('Get Service History Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get earnings summary for provider
exports.getEarningsSummary = async (req, res) => {
    const userId = req.userId;

    try {
        const provider = await Provider.findOne({ userId });
        if (!provider) {
            return res.status(404).json({ message: 'Provider profile not found' });
        }

        const completedJobs = await Job.find({
            providerId: provider._id,
            status: 'completed',
        });

        const totalEarnings = completedJobs.reduce((sum, job) => sum + (job.actualPrice || 0), 0);
        const jobsCompleted = completedJobs.length;

        res.json({
            totalEarnings,
            jobsCompleted,
            rating: provider.rating,
            totalRatings: provider.totalRatings,
        });
    } catch (error) {
        console.error('Get Earnings Summary Error:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
