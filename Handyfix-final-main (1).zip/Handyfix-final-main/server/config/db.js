const mongoose = require('mongoose');
const dotenv = require('dotenv');
const { MongoMemoryServer } = require('mongodb-memory-server');

dotenv.config();

let mongoServer = null;

const connectDB = async () => {
  try {
    let mongoURI = process.env.MONGODB_URI;

    // Use in-memory MongoDB for development if no MONGODB_URI is set
    if (!mongoURI) {
      console.log('Starting in-memory MongoDB for development...');
      mongoServer = await MongoMemoryServer.create();
      mongoURI = mongoServer.getUri();
    }

    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000,
    });

    console.log('MongoDB Connected Successfully');
  } catch (error) {
    console.error('MongoDB Connection Error:', error.message);
    console.warn('Continuing without MongoDB. Some features may not work.');
    // Don't exit - allow server to start anyway
  }
};

module.exports = connectDB;
