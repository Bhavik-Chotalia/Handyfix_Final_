const db = require('../server/config/db');
const bcrypt = require('bcrypt');

async function seedAdmin() {
    try {
        const email = 'admin@example.com';
        const password = 'adminpassword';
        const hashedPassword = await bcrypt.hash(password, 10);

        // Check if admin exists
        const [existing] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
        if (existing.length > 0) {
            console.log('Admin already exists.');
            process.exit(0);
        }

        await db.execute(
            'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
            ['Super Admin', email, hashedPassword, 'admin']
        );

        console.log('Admin created successfully.');
        console.log('Email: admin@example.com');
        console.log('Password: adminpassword');
        process.exit(0);

    } catch (error) {
        console.error(error);
        process.exit(1);
    }
}

seedAdmin();
